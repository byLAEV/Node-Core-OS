#!/usr/bin/env python3
"""Create portable public fixtures for LAEV HUC Standalone 0.7."""
from __future__ import annotations
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import huc_standalone as huc

OUT = ROOT / "demo" / "standalone"


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    with tempfile.TemporaryDirectory(prefix="huc-standalone-demo-") as td:
        temp = Path(td)
        workspace = temp / "issuer"
        holder = temp / "holder"
        init = huc.initialize(workspace, issuer_id="LAEV-DEMO-ISSUER", state_ttl_seconds=600)
        pin = init["trust_anchor_sha256"]
        request = huc.generate_request(holder, "LAEV HUC Standalone Demonstration")
        issued = huc.issue(workspace, Path(request["csr_file"]), days=365)
        cert = Path(issued["certificate_file"])
        key = Path(request["private_key_file"])
        active_bundle = OUT / "credential-active.zip"
        huc.export_bundle(workspace, cert, active_bundle)
        verified = huc.verify_bundle(active_bundle, pin)

        challenge = OUT / "direct-challenge.json"
        huc.create_challenge(issued["certificate_sha256_der"], "demo.relying-party.local", challenge, 120)
        response = OUT / "direct-response.json"
        huc.respond_to_challenge(challenge, active_bundle, key, response)
        direct_result = huc.verify_response(challenge, response, pin,
            "demo.relying-party.local", temp / "replay-store.json")

        # Renewal consumes first UTXO and turns old cert SUPERSEDED.
        holder2 = temp / "holder-renewed"
        request2 = huc.generate_request(holder2, "LAEV HUC Standalone Demonstration")
        renewed = huc.renew(workspace, cert, Path(request2["csr_file"]), days=365)
        renewed_cert = Path(renewed["certificate_file"])
        renewed_bundle = OUT / "credential-renewed-active.zip"
        old_bundle = OUT / "credential-superseded.zip"
        huc.export_bundle(workspace, renewed_cert, renewed_bundle)
        huc.export_bundle(workspace, cert, old_bundle)
        renewed_check = huc.verify_bundle(renewed_bundle, pin)
        old_check = huc.verify_bundle(old_bundle, pin)

        # Revocation consumes current UTXO and produces a fresh signed status receipt.
        huc.revoke(workspace, renewed_cert, "demo-revocation")
        revoked_bundle = OUT / "credential-revoked.zip"
        huc.export_bundle(workspace, renewed_cert, revoked_bundle)
        revoked_check = huc.verify_bundle(revoked_bundle, pin)

        # Public files only; never copy issuer/CA/holder private keys.
        public_dir = OUT / "public-artifacts"
        public_dir.mkdir()
        for name in [huc.CA_CERT, huc.ISSUER_PUBLIC, huc.POLICY_FILE, huc.ANCHOR_FILE]:
            shutil.copy2(workspace / name, public_dir / name)
        shutil.copy2(cert, public_dir / "certificate-issued.pem")
        shutil.copy2(Path(issued["consensus_certificate_file"]), public_dir / "huc-cc-issued.json")
        shutil.copy2(Path(issued["state_attestation_file"]), public_dir / "state-after-renewal-superseded.json")
        shutil.copy2(renewed_cert, public_dir / "certificate-renewed.pem")
        shutil.copy2(Path(renewed["consensus_certificate_file"]), public_dir / "huc-cc-renewed.json")
        shutil.copy2(Path(renewed["state_attestation_file"]), public_dir / "state-revoked.json")

        results = {
            "version": huc.VERSION,
            "architecture": "standalone X.509 + HUC-CC + issuer-signed logical UTXO state",
            "nodes_required": False,
            "blockchain_required": False,
            "transaction_fees": False,
            "optional_direct_challenge_response": True,
            "trust_anchor_sha256": pin,
            "initial_issuance": {"result": verified["result"], "utxo_status": verified["utxo_status"]},
            "direct_challenge_response": {"result": direct_result["result"],
                "holder_proof_of_possession": direct_result["holder_proof_of_possession"],
                "audience": direct_result["audience"], "replay_protection": direct_result["replay_protection"]},
            "renewed_certificate": {"result": renewed_check["result"], "utxo_status": renewed_check["utxo_status"]},
            "previous_certificate": {"result": old_check["result"], "utxo_status": old_check["utxo_status"]},
            "revoked_certificate": {"result": revoked_check["result"], "utxo_status": revoked_check["utxo_status"]},
            "checks": {
                "offline_package_valid": verified["hybrid_valid"],
                "direct_holder_proof_valid": direct_result["holder_proof_of_possession"],
                "renewal_consumed_previous_utxo": old_check["utxo_status"] == "SUPERSEDED",
                "renewed_certificate_active": renewed_check["hybrid_valid"],
                "revocation_invalidates_current_state": revoked_check["utxo_status"] == "REVOKED" and not revoked_check["hybrid_valid"],
                "no_private_key_files_in_public_demo": True,
            },
        }
        (OUT / "demo-results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
        (OUT / "trust-anchor.sha256").write_text(pin + "\n")
        (OUT / "README.md").write_text("""# LAEV HUC Standalone 0.7 — demostración pública

Esta demo contiene paquetes portátiles y mensajes directos, sin nodos ni blockchain.

- `credential-active.zip`: X.509 + HUC-CC + estado UTXO activo.
- `credential-renewed-active.zip`: nuevo certificado activo tras renovar.
- `credential-superseded.zip`: certificado anterior con estado SUPERSEDED.
- `credential-revoked.zip`: certificado renovado con estado REVOKED.
- `direct-challenge.json`: desafío de la aplicación/verificador.
- `direct-response.json`: respuesta del titular con el paquete y prueba de posesión de clave.
- `public-artifacts/`: archivos de inspección sin claves privadas.
- `trust-anchor.sha256`: pin externo que debe compartirse por un canal independiente.

Resultados observados en `demo-results.json`.

Los mensajes directos son archivos JSON transportables por QR, NFC, Bluetooth, AirDrop/Nearby Share, correo o canal seguro. No se levanta ningún servidor HUC ni se requiere una red de nodos.
""", encoding="utf-8")
        if not all(results["checks"].values()):
            raise SystemExit("Una comprobación de demostración falló")
        print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
