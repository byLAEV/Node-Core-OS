# LAEV HUC Standalone 0.7 — demostración pública

Esta demo contiene paquetes portátiles y mensajes directos, sin nodos ni blockchain.

- `credential-active.zip`: X.509 + HUC-CC + estado UTXO activo.
- `credential-renewed-active.zip`: nuevo certificado activo tras renovar.
- `credential-superseded.zip`: certificado anterior con estado SUPERSEDED.
- `credential-revoked.zip`: certificado renovado con estado REVOKED.
- `direct-challenge.json`: desafío de la aplicación/verificador.
- `direct-response.json`: respuesta del titular con el paquete y prueba de posesión de clave.
- `public-artifacts/`: archivos de inspección sin claves privadas.
- `trust-anchor.sha256`: pin externo que debe compartirse por un canal independiente.

Resultados observados en `demo-results.json`.

Los mensajes directos son archivos JSON transportables por QR, NFC, Bluetooth, AirDrop/Nearby Share, correo o canal seguro. No se levanta ningún servidor HUC ni se requiere una red de nodos.
