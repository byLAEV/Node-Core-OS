#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
import tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import huc_standalone as huc

DEMO = ROOT / "demo" / "standalone"
PIN = (DEMO / "trust-anchor.sha256").read_text().strip()

active = huc.verify_bundle(DEMO / "credential-active.zip", PIN)
renewed = huc.verify_bundle(DEMO / "credential-renewed-active.zip", PIN)
superseded = huc.verify_bundle(DEMO / "credential-superseded.zip", PIN)
revoked = huc.verify_bundle(DEMO / "credential-revoked.zip", PIN)
with tempfile.TemporaryDirectory(prefix="huc-demo-replay-") as td:
    direct = huc.verify_response(DEMO / "direct-challenge.json", DEMO / "direct-response.json",
                                 PIN, "demo.relying-party.local", Path(td) / "replay-store.json")
results = {
    "active": active["result"],
    "renewed": renewed["result"],
    "superseded": superseded["result"],
    "revoked": revoked["result"],
    "direct_exchange": direct["result"],
    "direct_holder_proof": direct["holder_proof_of_possession"],
}
assert results == {
    "active": "VALID", "renewed": "VALID", "superseded": "INVALID",
    "revoked": "INVALID", "direct_exchange": "VALID", "direct_holder_proof": True,
}
print(json.dumps(results, indent=2))
