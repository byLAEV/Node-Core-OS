#!/usr/bin/env python3
"""LAEV HUC Standalone 0.7 — certificate-native verification without node networks.

X.509 + complementary HUC-CC + issuer-signed logical UTXO state attestation.
Optional direct holder/verifier challenge-response uses a portable JSON message;
no HUC server, validator nodes, blockchain, token or transaction fee is required.

Laboratory reference implementation. Not a public CA or production PKI product.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from filelock import FileLock, Timeout
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, padding, rsa
from cryptography.x509.oid import NameOID

VERSION = "0.7.0"
POLICY_SCHEMA = "LAEV-HUC-STANDALONE-POLICY-1"
ANCHOR_SCHEMA = "LAEV-HUC-STANDALONE-ANCHOR-1"
LEDGER_SCHEMA = "LAEV-HUC-STANDALONE-UTXO-1"
CC_TYPE = "LAEV-HUC-CC"
CC_VERSION = "1"
STATE_SCHEMA = "LAEV-HUC-STATE-ATTESTATION-1"
PACKAGE_SCHEMA = "LAEV-HUC-STANDALONE-PACKAGE-1"
CHALLENGE_SCHEMA = "LAEV-HUC-DIRECT-CHALLENGE-1"
RESPONSE_SCHEMA = "LAEV-HUC-DIRECT-RESPONSE-1"

CA_CERT = "ca_certificate.pem"
CA_KEY = "ca_private_key.pem"
ISSUER_PUBLIC = "issuer_public.pem"
ISSUER_KEY = "issuer_private.pem"
POLICY_FILE = "huc_policy.json"
ANCHOR_FILE = "trust_anchor.json"
LEDGER_FILE = "utxo_ledger.jsonl"
CERT_DIR = "certificates"
MAX_CERT_DAYS = 825
DEFAULT_STATE_TTL = 300
MAX_CHALLENGE_TTL = 300
MAX_PACKAGE_BYTES = 10 * 1024 * 1024
MAX_JSON_SAFE_INT = 9007199254740991


def _reject_unsafe(value: Any) -> None:
    if isinstance(value, float):
        raise ValueError("El JSON HUC no permite números de punto flotante")
    if isinstance(value, int) and not isinstance(value, bool) and abs(value) > MAX_JSON_SAFE_INT:
        raise ValueError("Entero fuera del rango seguro JSON")
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str) or not key.isascii():
                raise ValueError("Las claves JSON protocolarias deben ser ASCII")
            _reject_unsafe(item)
    elif isinstance(value, list):
        for item in value:
            _reject_unsafe(item)


def canonical_json(value: Any) -> bytes:
    _reject_unsafe(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"Propiedad JSON duplicada: {key}")
        out[key] = value
    return out


def strict_json_loads(raw: str) -> Any:
    return json.loads(raw, object_pairs_hook=_unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"Constante JSON no permitida: {value}")))


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def obj_hash(value: Any) -> str:
    return sha256(canonical_json(value))


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None = None) -> str:
    dt = dt or now_utc()
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def parse_utc(value: str) -> datetime:
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception as exc:
        raise ValueError("Fecha UTC inválida") from exc
    if result.tzinfo is None:
        raise ValueError("La fecha debe incluir zona horaria")
    return result.astimezone(timezone.utc)


def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    import tempfile as _tempfile
    fd, tmp = _tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(tmp, mode)
        except OSError:
            pass
        os.replace(tmp, path)
        try:
            os.chmod(path, mode)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def write_json(path: Path, value: Any, mode: int = 0o600) -> None:
    atomic_write(path, json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False).encode("utf-8") + b"\n", mode)


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = strict_json_loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"JSON inválido en {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"Se esperaba objeto JSON en {path}")
    return value


def save_private(key: Any, path: Path) -> None:
    raw = key.private_bytes(serialization.Encoding.PEM,
                            serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption())
    atomic_write(path, raw, 0o600)


def load_private(path: Path) -> Any:
    return serialization.load_pem_private_key(path.read_bytes(), password=None)


def public_pem(key: Any) -> bytes:
    return key.public_bytes(serialization.Encoding.PEM,
                            serialization.PublicFormat.SubjectPublicKeyInfo)


def public_der(key: Any) -> bytes:
    return key.public_bytes(serialization.Encoding.DER,
                            serialization.PublicFormat.SubjectPublicKeyInfo)


def cert_der(cert: x509.Certificate) -> bytes:
    return cert.public_bytes(serialization.Encoding.DER)


def cert_hash(cert: x509.Certificate) -> str:
    return sha256(cert_der(cert))


def cert_bounds(cert: x509.Certificate) -> tuple[datetime, datetime]:
    before = getattr(cert, "not_valid_before_utc", None)
    after = getattr(cert, "not_valid_after_utc", None)
    if before is None:
        before = cert.not_valid_before.replace(tzinfo=timezone.utc)
    if after is None:
        after = cert.not_valid_after.replace(tzinfo=timezone.utc)
    return before, after


def _verify_ed(public_key: ed25519.Ed25519PublicKey, payload: dict[str, Any], signature_b64: str) -> None:
    try:
        signature = base64.b64decode(signature_b64, validate=True)
        public_key.verify(signature, canonical_json(payload))
    except (ValueError, InvalidSignature) as exc:
        raise ValueError("Firma Ed25519 inválida") from exc


def _sign_ed(private_key: ed25519.Ed25519PrivateKey, payload: dict[str, Any]) -> str:
    return base64.b64encode(private_key.sign(canonical_json(payload))).decode("ascii")


def _verify_ca(ca_cert: x509.Certificate) -> None:
    if ca_cert.subject != ca_cert.issuer:
        raise ValueError("La CA demo debe ser autofirmada")
    pub = ca_cert.public_key()
    if not isinstance(pub, rsa.RSAPublicKey):
        raise ValueError("La CA debe utilizar RSA")
    try:
        pub.verify(ca_cert.signature, ca_cert.tbs_certificate_bytes,
                   padding.PKCS1v15(), ca_cert.signature_hash_algorithm)
    except InvalidSignature as exc:
        raise ValueError("Firma autofirmada de CA inválida") from exc
    try:
        constraints = ca_cert.extensions.get_extension_for_class(x509.BasicConstraints).value
    except x509.ExtensionNotFound as exc:
        raise ValueError("CA sin BasicConstraints") from exc
    if not constraints.ca:
        raise ValueError("BasicConstraints CA no está activado")


def verify_leaf_signature(cert: x509.Certificate, ca_cert: x509.Certificate) -> None:
    if cert.issuer != ca_cert.subject:
        raise ValueError("Issuer del certificado no coincide con la CA")
    try:
        constraints = cert.extensions.get_extension_for_class(x509.BasicConstraints).value
    except x509.ExtensionNotFound as exc:
        raise ValueError("Certificado final sin BasicConstraints") from exc
    if constraints.ca:
        raise ValueError("El certificado final no puede ser CA")
    pub = ca_cert.public_key()
    if not isinstance(pub, rsa.RSAPublicKey):
        raise ValueError("La CA no utiliza RSA")
    try:
        pub.verify(cert.signature, cert.tbs_certificate_bytes,
                   padding.PKCS1v15(), cert.signature_hash_algorithm)
    except InvalidSignature as exc:
        raise ValueError("Firma X.509 inválida") from exc


def policy_hash(policy: dict[str, Any]) -> str:
    return obj_hash(policy)


def anchor_hash(anchor: dict[str, Any]) -> str:
    return obj_hash(anchor)


def initialize(workspace: Path, ca_name: str = "LAEV HUC Standalone CA",
                issuer_id: str = "LAEV-HUC-ISSUER", state_ttl_seconds: int = DEFAULT_STATE_TTL) -> dict[str, Any]:
    workspace = workspace.resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    protected = [CA_CERT, CA_KEY, ISSUER_PUBLIC, ISSUER_KEY, POLICY_FILE, ANCHOR_FILE, LEDGER_FILE]
    if any((workspace / name).exists() for name in protected):
        raise FileExistsError("El workspace ya está inicializado; no se sobrescriben claves")
    if not 30 <= state_ttl_seconds <= 86400:
        raise ValueError("state_ttl_seconds debe estar entre 30 y 86400")
    if not re.fullmatch(r"[A-Za-z0-9._-]{3,64}", issuer_id):
        raise ValueError("issuer_id inválido")

    ca_key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, ca_name)])
    now = now_utc().replace(tzinfo=None)
    ca_cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
        .public_key(ca_key.public_key()).serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5)).not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
        .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
            key_encipherment=False, data_encipherment=False, key_agreement=False,
            key_cert_sign=True, crl_sign=True, encipher_only=None, decipher_only=None), critical=True)
        .sign(ca_key, hashes.SHA256()))
    issuer_key = ed25519.Ed25519PrivateKey.generate()
    issuer_public = issuer_key.public_key()
    save_private(ca_key, workspace / CA_KEY)
    atomic_write(workspace / CA_CERT, ca_cert.public_bytes(serialization.Encoding.PEM), 0o644)
    save_private(issuer_key, workspace / ISSUER_KEY)
    atomic_write(workspace / ISSUER_PUBLIC, public_pem(issuer_public), 0o644)
    (workspace / CERT_DIR).mkdir(exist_ok=True)

    policy = {
        "schema": POLICY_SCHEMA,
        "protocol": "LAEV-HUC-STANDALONE/0.7",
        "issuer_id": issuer_id,
        "signature_algorithm": "Ed25519",
        "consensus_mode": "ISSUER_SIGNED_POLICY",
        "required_signatures": 1,
        "rules": {
            "x509_required": True,
            "huc_cc_required": True,
            "utxo_state_attestation_required": True,
            "certificate_transferable": False,
            "revoked_certificate_reactivation_allowed": False,
            "state_attestation_ttl_seconds": state_ttl_seconds,
            "direct_challenge_response_supported": True,
        },
    }
    write_json(workspace / POLICY_FILE, policy, 0o644)
    atomic_write(workspace / LEDGER_FILE, b"", 0o600)
    anchor = {
        "schema": ANCHOR_SCHEMA,
        "protocol_version": VERSION,
        "issuer_id": issuer_id,
        "created_at_utc": iso(),
        "ca_certificate_der_sha256": sha256(cert_der(ca_cert)),
        "issuer_public_key_der_sha256": sha256(public_der(issuer_public)),
        "policy_sha256": policy_hash(policy),
    }
    write_json(workspace / ANCHOR_FILE, anchor, 0o644)
    return {"result": "initialized", "protocol_version": VERSION,
            "workspace": str(workspace), "issuer_id": issuer_id,
            "trust_anchor_sha256": anchor_hash(anchor),
            "policy_sha256": policy_hash(policy),
            "state_ttl_seconds": state_ttl_seconds,
            "warning": "Claves privadas demo sin cifrar; no usar en producción."}


def load_trust(workspace: Path, expected_pin: str | None = None) -> dict[str, Any]:
    anchor = read_json(workspace / ANCHOR_FILE)
    policy = read_json(workspace / POLICY_FILE)
    ca_cert = x509.load_pem_x509_certificate((workspace / CA_CERT).read_bytes())
    issuer_public = serialization.load_pem_public_key((workspace / ISSUER_PUBLIC).read_bytes())
    if not isinstance(issuer_public, ed25519.Ed25519PublicKey):
        raise ValueError("La clave pública de emisor debe ser Ed25519")
    if anchor.get("schema") != ANCHOR_SCHEMA or policy.get("schema") != POLICY_SCHEMA:
        raise ValueError("Ancla o política HUC no reconocida")
    actual_anchor = anchor_hash(anchor)
    if expected_pin and actual_anchor.lower() != expected_pin.strip().lower():
        raise ValueError("La huella externa del ancla no coincide")
    if anchor.get("ca_certificate_der_sha256") != sha256(cert_der(ca_cert)):
        raise ValueError("Certificado CA no coincide con el ancla")
    if anchor.get("issuer_public_key_der_sha256") != sha256(public_der(issuer_public)):
        raise ValueError("Clave pública de emisor no coincide con el ancla")
    if anchor.get("policy_sha256") != policy_hash(policy):
        raise ValueError("Política no coincide con el ancla")
    if policy.get("issuer_id") != anchor.get("issuer_id"):
        raise ValueError("Issuer ID no coincide")
    return {"anchor": anchor, "anchor_sha256": actual_anchor, "policy": policy,
            "policy_sha256": policy_hash(policy), "ca_cert": ca_cert,
            "issuer_public": issuer_public}


def generate_request(out_dir: Path, common_name: str, key_size: int = 2048) -> dict[str, Any]:
    if not common_name.strip():
        raise ValueError("Common Name no puede estar vacío")
    if key_size < 2048 or key_size > 4096:
        raise ValueError("RSA key size debe estar entre 2048 y 4096")
    out_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", common_name.strip()).strip("._-") or "holder"
    stamp = now_utc().strftime("%Y%m%dT%H%M%SZ")
    key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, common_name.strip())])
    csr = x509.CertificateSigningRequestBuilder().subject_name(name).sign(key, hashes.SHA256())
    key_path = out_dir / f"{safe}-{stamp}-private.pem"
    csr_path = out_dir / f"{safe}-{stamp}.csr.pem"
    save_private(key, key_path)
    atomic_write(csr_path, csr.public_bytes(serialization.Encoding.PEM), 0o644)
    return {"csr_file": str(csr_path.resolve()), "private_key_file": str(key_path.resolve()),
            "subject": csr.subject.rfc4514_string(), "proof_of_possession": csr.is_signature_valid,
            "warning": "La clave privada del titular permanece bajo su control."}


def validate_csr(csr_path: Path) -> x509.CertificateSigningRequest:
    csr = x509.load_pem_x509_csr(csr_path.read_bytes())
    if not csr.is_signature_valid:
        raise ValueError("CSR no demuestra posesión de su clave")
    cn = csr.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    if not cn or not cn[0].value.strip():
        raise ValueError("CSR requiere Common Name")
    if not isinstance(csr.public_key(), rsa.RSAPublicKey) or csr.public_key().key_size < 2048:
        raise ValueError("CSR requiere clave pública RSA de al menos 2048 bits")
    if list(csr.extensions):
        raise ValueError("Este MVP no acepta extensiones CSR sin política explícita")
    return csr


def make_certificate(csr: x509.CertificateSigningRequest, ca_key: rsa.RSAPrivateKey,
                     ca_cert: x509.Certificate, days: int) -> x509.Certificate:
    if not 1 <= days <= MAX_CERT_DAYS:
        raise ValueError(f"Vigencia permitida: 1 a {MAX_CERT_DAYS} días")
    now = now_utc().replace(tzinfo=None)
    return (x509.CertificateBuilder().subject_name(csr.subject).issuer_name(ca_cert.subject)
        .public_key(csr.public_key()).serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5)).not_valid_after(now + timedelta(days=days))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(csr.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
        .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=True,
            key_encipherment=True, data_encipherment=False, key_agreement=False,
            key_cert_sign=False, crl_sign=False, encipher_only=None, decipher_only=None), critical=True)
        .sign(ca_key, hashes.SHA256()))


def _ledger_state(workspace: Path, trust: dict[str, Any]) -> dict[str, Any]:
    active: dict[str, dict[str, Any]] = {}
    statuses: dict[str, str] = {}
    known: set[str] = set()
    previous_event_hash: str | None = None
    events: list[dict[str, Any]] = []
    issuer_key = trust["issuer_public"]
    ledger_path = workspace / LEDGER_FILE
    if not ledger_path.exists():
        raise FileNotFoundError("No existe utxo_ledger.jsonl")
    for line_no, line in enumerate(ledger_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            event = strict_json_loads(line)
            if not isinstance(event, dict):
                raise ValueError("Evento no es objeto JSON")
            payload = event["payload"]
            if payload.get("schema") != LEDGER_SCHEMA or payload.get("sequence") != len(events):
                raise ValueError("Schema o secuencia incorrectos")
            if payload.get("previous_event_hash") != previous_event_hash:
                raise ValueError("Cadena de eventos rota")
            event_hash = obj_hash(payload)
            if event.get("event_hash") != event_hash:
                raise ValueError("event_hash incorrecto")
            _verify_ed(issuer_key, {"event_hash": event_hash}, event.get("signature", ""))
            action = payload.get("action")
            cert_digest = payload.get("certificate_sha256_der")
            prev_cert = payload.get("previous_certificate_sha256_der")
            prev_outpoint = payload.get("previous_outpoint")
            output = payload.get("output")
            if not isinstance(cert_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", cert_digest):
                raise ValueError("Hash de certificado inválido")
            if action in {"ISSUE", "RENEW"}:
                txid = obj_hash({k: v for k, v in payload.items() if k != "output"})
                expected = {"txid": txid, "vout": 0}
                if output != expected:
                    raise ValueError("Outpoint de salida inválido")
                if cert_digest in known:
                    raise ValueError("Certificado duplicado")
                if action == "ISSUE":
                    if prev_cert is not None or prev_outpoint is not None:
                        raise ValueError("ISSUE no debe consumir una entrada")
                else:
                    if not prev_cert or prev_cert not in active or active[prev_cert] != prev_outpoint:
                        raise ValueError("RENEW no consume el UTXO activo exacto")
                    del active[prev_cert]
                    statuses[prev_cert] = "SUPERSEDED"
                active[cert_digest] = output
                statuses[cert_digest] = "ACTIVE"
                known.add(cert_digest)
            elif action == "REVOKE":
                if cert_digest not in active or active[cert_digest] != prev_outpoint:
                    raise ValueError("REVOKE no consume el UTXO activo exacto")
                if output is not None or not isinstance(payload.get("reason"), str) or not payload["reason"].strip():
                    raise ValueError("REVOKE requiere motivo y no crea salida")
                del active[cert_digest]
                statuses[cert_digest] = "REVOKED"
            else:
                raise ValueError("Operación ledger desconocida")
            previous_event_hash = event_hash
            events.append(event)
        except Exception as exc:
            raise ValueError(f"Ledger inválido en línea {line_no}: {exc}") from exc
    return {"events": events, "active": active, "statuses": statuses,
            "last_event_hash": previous_event_hash, "event_count": len(events)}


def _append_event(workspace: Path, trust: dict[str, Any], action: str, cert_digest: str,
                  previous_cert: str | None = None, previous_outpoint: dict[str, Any] | None = None,
                  reason: str | None = None) -> dict[str, Any]:
    lock = FileLock(str(workspace / (LEDGER_FILE + ".lock")), timeout=20)
    try:
        with lock:
            state = _ledger_state(workspace, trust)
            if action == "ISSUE":
                if cert_digest in state["statuses"]:
                    raise ValueError("Certificado ya registrado")
            elif action == "RENEW":
                if not previous_cert or previous_cert not in state["active"]:
                    raise ValueError("Certificado anterior no está activo")
                if state["active"][previous_cert] != previous_outpoint:
                    raise ValueError("Outpoint anterior no coincide")
                if cert_digest in state["statuses"]:
                    raise ValueError("Certificado nuevo ya registrado")
            elif action == "REVOKE":
                if cert_digest not in state["active"] or state["active"][cert_digest] != previous_outpoint:
                    raise ValueError("Certificado no está activo")
                if not reason or not reason.strip():
                    raise ValueError("Revocación requiere motivo")
            else:
                raise ValueError("Acción desconocida")
            payload = {
                "schema": LEDGER_SCHEMA,
                "sequence": state["event_count"],
                "previous_event_hash": state["last_event_hash"],
                "action": action,
                "certificate_sha256_der": cert_digest,
                "previous_certificate_sha256_der": previous_cert,
                "previous_outpoint": previous_outpoint,
                "output": None,
                "created_at_utc": iso(),
                "reason": reason,
            }
            txid = obj_hash({k: v for k, v in payload.items() if k != "output"})
            if action in {"ISSUE", "RENEW"}:
                payload["output"] = {"txid": txid, "vout": 0}
            event_hash = obj_hash(payload)
            issuer_key = load_private(workspace / ISSUER_KEY)
            event = {"payload": payload, "event_hash": event_hash,
                     "signature": _sign_ed(issuer_key, {"event_hash": event_hash})}
            with (workspace / LEDGER_FILE).open("ab") as handle:
                handle.write(canonical_json(event) + b"\n")
                handle.flush()
                os.fsync(handle.fileno())
            _ledger_state(workspace, trust)
            return event
    except Timeout as exc:
        raise TimeoutError("No se obtuvo bloqueo del registro UTXO local") from exc


def _cc_payload(trust: dict[str, Any], cert: x509.Certificate,
                outpoint: dict[str, Any], sequence: int) -> dict[str, Any]:
    return {
        "consensus_certificate_id": "huc-cc:" + obj_hash({
            "certificate_sha256_der": cert_hash(cert),
            "initial_utxo_outpoint": outpoint,
            "policy_sha256": trust["policy_sha256"],
        }),
        "certificate_sha256_der": cert_hash(cert),
        "certificate_serial_number": str(cert.serial_number),
        "initial_utxo_outpoint": outpoint,
        "utxo_sequence_at_issuance": sequence,
        "issuer_id": trust["policy"]["issuer_id"],
        "policy_sha256": trust["policy_sha256"],
        "consensus_mode": "ISSUER_SIGNED_POLICY",
        "required_signatures": 1,
        "operation": "ISSUE_OR_RENEW",
        "issued_at_utc": iso(),
        "not_after_utc": iso(cert_bounds(cert)[1]),
    }


def _write_cc(workspace: Path, cert: x509.Certificate, trust: dict[str, Any],
              outpoint: dict[str, Any], sequence: int) -> Path:
    payload = _cc_payload(trust, cert, outpoint, sequence)
    key = load_private(workspace / ISSUER_KEY)
    cc = {"type": CC_TYPE, "version": CC_VERSION, "payload": payload,
          "signature": _sign_ed(key, payload)}
    path = workspace / CERT_DIR / f"consensus-{cert_hash(cert)}.json"
    write_json(path, cc, 0o644)
    return path


def _write_state_attestation(workspace: Path, cert: x509.Certificate,
                             trust: dict[str, Any], cc_path: Path) -> Path:
    state = _ledger_state(workspace, trust)
    digest = cert_hash(cert)
    status = state["statuses"].get(digest, "NOT_REGISTERED")
    cc_digest = sha256(canonical_json(read_json(cc_path)))
    payload = {
        "schema": STATE_SCHEMA,
        "issuer_id": trust["policy"]["issuer_id"],
        "certificate_sha256_der": digest,
        "consensus_certificate_sha256": cc_digest,
        "status": status,
        "utxo_outpoint": state["active"].get(digest),
        "ledger_sequence": max(0, state["event_count"] - 1),
        "ledger_event_count": state["event_count"],
        "ledger_head_hash": state["last_event_hash"],
        "issued_at_utc": iso(),
        "expires_at_utc": iso(now_utc() + timedelta(seconds=trust["policy"]["rules"]["state_attestation_ttl_seconds"])),
    }
    key = load_private(workspace / ISSUER_KEY)
    attestation = {"payload": payload, "signature": _sign_ed(key, payload)}
    path = workspace / CERT_DIR / f"state-{digest}.json"
    write_json(path, attestation, 0o644)
    return path


def issue(workspace: Path, csr_path: Path, days: int = 365) -> dict[str, Any]:
    workspace = workspace.resolve()
    csr = validate_csr(csr_path)
    trust = load_trust(workspace)
    ca_key = load_private(workspace / CA_KEY)
    cert = make_certificate(csr, ca_key, trust["ca_cert"], days)
    digest = cert_hash(cert)
    cert_path = workspace / CERT_DIR / f"certificate-{digest}.pem"
    atomic_write(cert_path, cert.public_bytes(serialization.Encoding.PEM), 0o644)
    event = _append_event(workspace, trust, "ISSUE", digest)
    cc_path = _write_cc(workspace, cert, trust, event["payload"]["output"], event["payload"]["sequence"])
    state_path = _write_state_attestation(workspace, cert, trust, cc_path)
    return {"action": "ISSUE", "certificate_sha256_der": digest,
            "certificate_file": str(cert_path), "consensus_certificate_file": str(cc_path),
            "state_attestation_file": str(state_path), "utxo_outpoint": event["payload"]["output"],
            "private_key_note": "La clave privada del titular no se entrega al emisor."}


def renew(workspace: Path, old_certificate_path: Path, csr_path: Path, days: int = 365) -> dict[str, Any]:
    workspace = workspace.resolve()
    old_cert = x509.load_pem_x509_certificate(old_certificate_path.read_bytes())
    csr = validate_csr(csr_path)
    if old_cert.subject != csr.subject:
        raise ValueError("El sujeto del CSR nuevo debe coincidir con el certificado anterior")
    trust = load_trust(workspace)
    verify_leaf_signature(old_cert, trust["ca_cert"])
    state = _ledger_state(workspace, trust)
    old_hash = cert_hash(old_cert)
    old_outpoint = state["active"].get(old_hash)
    if not old_outpoint:
        raise ValueError("El certificado anterior no tiene estado UTXO activo")
    ca_key = load_private(workspace / CA_KEY)
    new_cert = make_certificate(csr, ca_key, trust["ca_cert"], days)
    new_hash = cert_hash(new_cert)
    new_path = workspace / CERT_DIR / f"certificate-{new_hash}.pem"
    atomic_write(new_path, new_cert.public_bytes(serialization.Encoding.PEM), 0o644)
    event = _append_event(workspace, trust, "RENEW", new_hash, old_hash, old_outpoint)
    cc_path = _write_cc(workspace, new_cert, trust, event["payload"]["output"], event["payload"]["sequence"])
    new_state = _write_state_attestation(workspace, new_cert, trust, cc_path)
    old_cc = workspace / CERT_DIR / f"consensus-{old_hash}.json"
    old_state_path = _write_state_attestation(workspace, old_cert, trust, old_cc)
    return {"action": "RENEW", "previous_certificate_sha256_der": old_hash,
            "certificate_sha256_der": new_hash, "certificate_file": str(new_path),
            "consensus_certificate_file": str(cc_path), "state_attestation_file": str(new_state),
            "previous_state_attestation_file": str(old_state_path),
            "utxo_outpoint": event["payload"]["output"]}


def revoke(workspace: Path, certificate_path: Path, reason: str) -> dict[str, Any]:
    if not reason.strip():
        raise ValueError("Motivo de revocación requerido")
    workspace = workspace.resolve()
    cert = x509.load_pem_x509_certificate(certificate_path.read_bytes())
    trust = load_trust(workspace)
    verify_leaf_signature(cert, trust["ca_cert"])
    state = _ledger_state(workspace, trust)
    digest = cert_hash(cert)
    outpoint = state["active"].get(digest)
    if not outpoint:
        raise ValueError("El certificado no está activo o ya fue consumido")
    event = _append_event(workspace, trust, "REVOKE", digest,
                          previous_outpoint=outpoint, reason=reason.strip())
    cc_path = workspace / CERT_DIR / f"consensus-{digest}.json"
    state_path = _write_state_attestation(workspace, cert, trust, cc_path)
    return {"action": "REVOKE", "certificate_sha256_der": digest,
            "status": "REVOKED", "consumed_utxo": outpoint,
            "state_attestation_file": str(state_path), "event_hash": event["event_hash"]}


def refresh_status(workspace: Path, certificate_path: Path) -> dict[str, Any]:
    workspace = workspace.resolve()
    cert = x509.load_pem_x509_certificate(certificate_path.read_bytes())
    trust = load_trust(workspace)
    verify_leaf_signature(cert, trust["ca_cert"])
    digest = cert_hash(cert)
    cc_path = workspace / CERT_DIR / f"consensus-{digest}.json"
    if not cc_path.exists():
        raise FileNotFoundError("No se encuentra el HUC-CC de este certificado")
    path = _write_state_attestation(workspace, cert, trust, cc_path)
    payload = read_json(path)["payload"]
    return {"state_attestation_file": str(path), "status": payload["status"],
            "ledger_sequence": payload["ledger_sequence"], "expires_at_utc": payload["expires_at_utc"]}


def _verify_cc(cc: dict[str, Any], cert: x509.Certificate, trust: dict[str, Any]) -> dict[str, Any]:
    if cc.get("type") != CC_TYPE or cc.get("version") != CC_VERSION:
        raise ValueError("HUC-CC desconocido")
    payload = cc.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("HUC-CC sin payload")
    if payload.get("certificate_sha256_der") != cert_hash(cert):
        raise ValueError("HUC-CC no está vinculado a este X.509")
    if payload.get("policy_sha256") != trust["policy_sha256"]:
        raise ValueError("HUC-CC usa otra política")
    if payload.get("issuer_id") != trust["policy"]["issuer_id"]:
        raise ValueError("HUC-CC issuer no coincide")
    if payload.get("certificate_serial_number") != str(cert.serial_number):
        raise ValueError("HUC-CC serial no coincide")
    outpoint = payload.get("initial_utxo_outpoint")
    if not isinstance(outpoint, dict) or not re.fullmatch(r"[0-9a-f]{64}", str(outpoint.get("txid", ""))) or outpoint.get("vout") != 0:
        raise ValueError("HUC-CC outpoint inicial inválido")
    expected_id = "huc-cc:" + obj_hash({
        "certificate_sha256_der": cert_hash(cert),
        "initial_utxo_outpoint": outpoint,
        "policy_sha256": trust["policy_sha256"],
    })
    if payload.get("consensus_certificate_id") != expected_id:
        raise ValueError("ID del HUC-CC inválido")
    try:
        cc_expiry = parse_utc(payload["not_after_utc"])
    except Exception as exc:
        raise ValueError("Vigencia HUC-CC inválida") from exc
    if cc_expiry != cert_bounds(cert)[1]:
        raise ValueError("Vigencia HUC-CC no coincide con X.509")
    _verify_ed(trust["issuer_public"], payload, cc.get("signature", ""))
    return payload


def verify_bundle(bundle_path: Path, expected_anchor_sha256: str,
                  max_state_age_seconds: int = DEFAULT_STATE_TTL) -> dict[str, Any]:
    if not expected_anchor_sha256:
        raise ValueError("Se requiere pin externo del ancla")
    if not 1 <= max_state_age_seconds <= 86400:
        raise ValueError("max_state_age_seconds fuera de rango")
    with tempfile.TemporaryDirectory(prefix="huc-standalone-verify-") as td:
        root = Path(td)
        with zipfile.ZipFile(bundle_path, "r") as archive:
            total = sum(item.file_size for item in archive.infolist())
            if total > MAX_PACKAGE_BYTES:
                raise ValueError("Paquete supera 10 MiB")
            for item in archive.infolist():
                dest = (root / item.filename).resolve()
                if root.resolve() not in dest.parents and dest != root.resolve():
                    raise ValueError("Ruta no permitida dentro del paquete")
            archive.extractall(root)
        manifest = read_json(root / "package_manifest.json")
        if manifest.get("schema") != PACKAGE_SCHEMA:
            raise ValueError("Paquete HUC no reconocido")
        if manifest.get("private_keys_included") is not False:
            raise ValueError("El manifiesto no garantiza ausencia de claves privadas")
        # Verify the package's files match the manifest hashes.
        for field, filename in [("certificate_sha256_der", "certificate.pem"),
                                 ("consensus_certificate_sha256", "consensus_certificate.json"),
                                 ("state_attestation_sha256", "state_attestation.json")]:
            raw = (root / filename).read_bytes()
            if filename == "certificate.pem":
                actual = cert_hash(x509.load_pem_x509_certificate(raw))
            elif filename == "consensus_certificate.json":
                actual = obj_hash(read_json(root / filename))
            else:
                actual = sha256(raw)
            if actual != manifest.get(field):
                raise ValueError(f"{filename} no coincide con package_manifest")
        anchor = read_json(root / ANCHOR_FILE)
        policy = read_json(root / POLICY_FILE)
        ca_cert = x509.load_pem_x509_certificate((root / CA_CERT).read_bytes())
        issuer_public = serialization.load_pem_public_key((root / ISSUER_PUBLIC).read_bytes())
        if not isinstance(issuer_public, ed25519.Ed25519PublicKey):
            raise ValueError("Clave pública de emisor inválida")
        actual_anchor = anchor_hash(anchor)
        if actual_anchor.lower() != expected_anchor_sha256.strip().lower():
            raise ValueError("La huella externa del ancla no coincide")
        if anchor.get("schema") != ANCHOR_SCHEMA or policy.get("schema") != POLICY_SCHEMA:
            raise ValueError("Ancla o política no reconocida")
        if anchor.get("ca_certificate_der_sha256") != sha256(cert_der(ca_cert)):
            raise ValueError("CA no coincide con ancla")
        if anchor.get("issuer_public_key_der_sha256") != sha256(public_der(issuer_public)):
            raise ValueError("Clave del emisor no coincide con ancla")
        if anchor.get("policy_sha256") != policy_hash(policy):
            raise ValueError("Política no coincide con ancla")
        if anchor.get("issuer_id") != policy.get("issuer_id"):
            raise ValueError("Issuer del ancla no coincide con política")
        if policy.get("consensus_mode") != "ISSUER_SIGNED_POLICY" or policy.get("required_signatures") != 1:
            raise ValueError("Perfil de consenso standalone no reconocido")
        _verify_ca(ca_cert)
        cert = x509.load_pem_x509_certificate((root / "certificate.pem").read_bytes())
        verify_leaf_signature(cert, ca_cert)
        now = now_utc()
        before, after = cert_bounds(cert)
        ca_before, ca_after = cert_bounds(ca_cert)
        if not (ca_before <= now <= ca_after):
            raise ValueError("CA fuera de vigencia")
        cert_time_valid = before <= now <= after
        cc = read_json(root / "consensus_certificate.json")
        cc_payload = _verify_cc(cc, cert, {
            "policy_sha256": policy_hash(policy), "policy": policy,
            "issuer_public": issuer_public,
        })
        attestation = read_json(root / "state_attestation.json")
        state_payload = attestation.get("payload")
        if not isinstance(state_payload, dict) or state_payload.get("schema") != STATE_SCHEMA:
            raise ValueError("Atestación de estado no reconocida")
        _verify_ed(issuer_public, state_payload, attestation.get("signature", ""))
        cert_digest = cert_hash(cert)
        cc_digest = sha256(canonical_json(cc))
        if state_payload.get("certificate_sha256_der") != cert_digest:
            raise ValueError("Atestación de estado vinculada a otro X.509")
        if state_payload.get("consensus_certificate_sha256") != cc_digest:
            raise ValueError("Atestación de estado vinculada a otro HUC-CC")
        if state_payload.get("issuer_id") != policy.get("issuer_id"):
            raise ValueError("Issuer de atestación no coincide")
        if (not isinstance(state_payload.get("ledger_event_count"), int)
                or state_payload.get("ledger_event_count") < 1
                or not isinstance(state_payload.get("ledger_sequence"), int)
                or state_payload.get("ledger_sequence") < 0
                or not isinstance(state_payload.get("ledger_head_hash"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", state_payload.get("ledger_head_hash", ""))):
            raise ValueError("Atestación no incluye un checkpoint UTXO válido")
        issued = parse_utc(state_payload.get("issued_at_utc", ""))
        expires = parse_utc(state_payload.get("expires_at_utc", ""))
        age = (now - issued).total_seconds()
        freshness_valid = 0 <= age <= max_state_age_seconds and now <= expires
        status = state_payload.get("status")
        if status == "ACTIVE":
            if not isinstance(state_payload.get("utxo_outpoint"), dict):
                raise ValueError("Estado ACTIVE sin UTXO")
            if state_payload.get("utxo_outpoint") != cc_payload.get("initial_utxo_outpoint"):
                raise ValueError("Outpoint ACTIVE no coincide con HUC-CC inicial")
        elif status in {"REVOKED", "SUPERSEDED"}:
            if state_payload.get("utxo_outpoint") is not None:
                raise ValueError("Estado consumido no debe conservar UTXO activo")
        else:
            raise ValueError("Estado UTXO desconocido")
        hybrid_valid = bool(cert_time_valid and freshness_valid and status == "ACTIVE")
        result = "VALID" if hybrid_valid else ("INVALID" if status in {"REVOKED", "SUPERSEDED"} or not cert_time_valid else "INDETERMINATE")
        return {
            "result": result,
            "hybrid_valid": hybrid_valid,
            "subject": cert.subject.rfc4514_string(),
            "serial_number": str(cert.serial_number),
            "certificate_sha256_der": cert_digest,
            "consensus_certificate_sha256": cc_digest,
            "x509_signature_valid": True,
            "huc_cc_valid": True,
            "huc_cc_signature_valid": True,
            "issuer_state_signature_valid": True,
            "certificate_time_valid": cert_time_valid,
            "state_freshness_valid": freshness_valid,
            "state_age_seconds": max(0, int(age)),
            "state_ttl_seconds": int((expires - issued).total_seconds()),
            "utxo_status": status,
            "utxo_outpoint": state_payload.get("utxo_outpoint"),
            "ledger_sequence": state_payload.get("ledger_sequence"),
            "ledger_head_hash": state_payload.get("ledger_head_hash"),
            "trust_anchor_sha256": actual_anchor,
            "external_trust_pin_supplied": True,
        }


def export_bundle(workspace: Path, certificate_path: Path, output: Path) -> dict[str, Any]:
    workspace = workspace.resolve()
    trust = load_trust(workspace)
    cert = x509.load_pem_x509_certificate(certificate_path.read_bytes())
    digest = cert_hash(cert)
    cc_path = workspace / CERT_DIR / f"consensus-{digest}.json"
    if not cc_path.exists():
        raise FileNotFoundError("No se encuentra el HUC-CC del certificado")
    state_path = _write_state_attestation(workspace, cert, trust, cc_path)
    cc = read_json(cc_path)
    state = read_json(state_path)
    manifest = {
        "schema": PACKAGE_SCHEMA,
        "version": VERSION,
        "certificate_sha256_der": digest,
        "consensus_certificate_sha256": sha256(canonical_json(cc)),
        "state_attestation_sha256": sha256(state_path.read_bytes()),
        "private_keys_included": False,
    }
    files = [
        (workspace / CA_CERT, CA_CERT),
        (workspace / ISSUER_PUBLIC, ISSUER_PUBLIC),
        (workspace / POLICY_FILE, POLICY_FILE),
        (workspace / ANCHOR_FILE, ANCHOR_FILE),
        (certificate_path, "certificate.pem"),
        (cc_path, "consensus_certificate.json"),
        (state_path, "state_attestation.json"),
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for source, name in files:
            archive.write(source, name)
        archive.writestr("package_manifest.json", json.dumps(manifest, indent=2) + "\n")
    return {"package": str(output.resolve()), "certificate_sha256_der": digest,
            "status": state["payload"]["status"], "private_keys_included": False,
            "trust_anchor_sha256": trust["anchor_sha256"]}


def create_challenge(certificate_sha256: str, audience: str, output: Path,
                     ttl_seconds: int = 120) -> dict[str, Any]:
    if not re.fullmatch(r"[0-9a-f]{64}", certificate_sha256):
        raise ValueError("certificate_sha256 debe ser SHA-256 hexadecimal")
    if not audience.strip() or len(audience) > 256:
        raise ValueError("audience requerida; máximo 256 caracteres")
    if not 10 <= ttl_seconds <= MAX_CHALLENGE_TTL:
        raise ValueError(f"ttl_seconds debe estar entre 10 y {MAX_CHALLENGE_TTL}")
    payload = {
        "schema": CHALLENGE_SCHEMA,
        "certificate_sha256_der": certificate_sha256,
        "audience": audience.strip(),
        "nonce": secrets.token_hex(32),
        "created_at_utc": iso(),
        "expires_at_utc": iso(now_utc() + timedelta(seconds=ttl_seconds)),
    }
    challenge = {"payload": payload, "challenge_id": obj_hash(payload)}
    write_json(output, challenge, 0o644)
    return {"challenge_file": str(output.resolve()), "challenge_id": challenge["challenge_id"],
            "audience": payload["audience"], "expires_at_utc": payload["expires_at_utc"]}


def _safe_extract_package(raw: bytes, target: Path) -> None:
    with zipfile.ZipFile(__import__("io").BytesIO(raw), "r") as archive:
        total = sum(item.file_size for item in archive.infolist())
        if total > MAX_PACKAGE_BYTES:
            raise ValueError("Paquete supera 10 MiB")
        for item in archive.infolist():
            dest = (target / item.filename).resolve()
            if target.resolve() not in dest.parents and dest != target.resolve():
                raise ValueError("Ruta ZIP no permitida")
        archive.extractall(target)


def respond_to_challenge(challenge_path: Path, bundle_path: Path,
                         holder_private_key_path: Path, output: Path) -> dict[str, Any]:
    challenge = read_json(challenge_path)
    payload = challenge.get("payload")
    if not isinstance(payload, dict) or payload.get("schema") != CHALLENGE_SCHEMA or challenge.get("challenge_id") != obj_hash(payload):
        raise ValueError("Challenge inválido")
    created = parse_utc(payload["created_at_utc"])
    expires = parse_utc(payload["expires_at_utc"])
    if expires <= created or expires - created > timedelta(seconds=MAX_CHALLENGE_TTL):
        raise ValueError("Ventana temporal del challenge inválida")
    if created > now_utc() + timedelta(minutes=2) or now_utc() > expires:
        raise ValueError("Challenge expirado o fechado en el futuro")
    raw_bundle = bundle_path.read_bytes()
    if len(raw_bundle) > MAX_PACKAGE_BYTES:
        raise ValueError("Paquete demasiado grande")
    with tempfile.TemporaryDirectory(prefix="huc-holder-proof-") as td:
        root = Path(td)
        _safe_extract_package(raw_bundle, root)
        cert = x509.load_pem_x509_certificate((root / "certificate.pem").read_bytes())
        if cert_hash(cert) != payload["certificate_sha256_der"]:
            raise ValueError("El challenge no corresponde al certificado del paquete")
    private = load_private(holder_private_key_path)
    if not isinstance(private, rsa.RSAPrivateKey):
        raise ValueError("La clave del titular debe ser RSA")
    # Make sure the holder's private key corresponds to the certificate.
    cert_public_der = public_der(cert.public_key())
    if public_der(private.public_key()) != cert_public_der:
        raise ValueError("La clave privada no corresponde al certificado presentado")
    message = canonical_json({"domain": "LAEV-HUC-DIRECT-CHALLENGE-0.7", "challenge": payload})
    signature = private.sign(message, padding.PKCS1v15(), hashes.SHA256())
    response = {
        "schema": RESPONSE_SCHEMA,
        "challenge": challenge,
        "credential_bundle_b64": base64.b64encode(raw_bundle).decode("ascii"),
        "holder_signature_b64": base64.b64encode(signature).decode("ascii"),
        "responded_at_utc": iso(),
    }
    write_json(output, response, 0o644)
    return {"response_file": str(output.resolve()), "challenge_id": challenge["challenge_id"],
            "certificate_sha256_der": payload["certificate_sha256_der"],
            "transport": "archivo JSON; puede transferirse por QR, Bluetooth, NFC o canal de datos seguro"}


def verify_response(challenge_path: Path, response_path: Path, expected_anchor_sha256: str,
                    expected_audience: str, replay_store: Path,
                    max_state_age_seconds: int = DEFAULT_STATE_TTL) -> dict[str, Any]:
    challenge = read_json(challenge_path)
    response = read_json(response_path)
    if response.get("schema") != RESPONSE_SCHEMA:
        raise ValueError("Respuesta HUC Direct desconocida")
    original_payload = challenge.get("payload")
    received_challenge = response.get("challenge")
    if not isinstance(original_payload, dict) or not isinstance(received_challenge, dict):
        raise ValueError("Challenge o respuesta incompletos")
    if challenge.get("challenge_id") != obj_hash(original_payload):
        raise ValueError("Challenge original alterado")
    if received_challenge != challenge:
        raise ValueError("La respuesta no corresponde exactamente al challenge emitido")
    if original_payload.get("audience") != expected_audience:
        raise ValueError("Audience incorrecta")
    now = now_utc()
    created = parse_utc(original_payload["created_at_utc"])
    expires = parse_utc(original_payload["expires_at_utc"])
    if expires <= created or expires - created > timedelta(seconds=MAX_CHALLENGE_TTL):
        raise ValueError("Ventana temporal del challenge inválida")
    if created > now + timedelta(minutes=2) or now > expires:
        raise ValueError("Challenge fuera de su ventana de validez")
    try:
        raw_bundle = base64.b64decode(response.get("credential_bundle_b64", ""), validate=True)
    except ValueError as exc:
        raise ValueError("Paquete de credencial no es Base64 válido") from exc
    with tempfile.TemporaryDirectory(prefix="huc-direct-verify-") as td:
        root = Path(td)
        _safe_extract_package(raw_bundle, root)
        cert = x509.load_pem_x509_certificate((root / "certificate.pem").read_bytes())
        cert_digest = cert_hash(cert)
        if cert_digest != original_payload.get("certificate_sha256_der"):
            raise ValueError("El certificado no corresponde al challenge")
        result = verify_bundle(Path(_write_temp_bundle(raw_bundle, root)), expected_anchor_sha256,
                               max_state_age_seconds)
        if not result["hybrid_valid"]:
            raise ValueError(f"Credencial no válida en challenge-response: {result['result']}")
        signature = base64.b64decode(response.get("holder_signature_b64", ""), validate=True)
        message = canonical_json({"domain": "LAEV-HUC-DIRECT-CHALLENGE-0.7", "challenge": original_payload})
        pub = cert.public_key()
        if not isinstance(pub, rsa.RSAPublicKey):
            raise ValueError("Clave pública del titular no soportada")
        try:
            pub.verify(signature, message, padding.PKCS1v15(), hashes.SHA256())
        except InvalidSignature as exc:
            raise ValueError("Prueba de posesión de clave privada inválida") from exc
    # A nonce is consumed only after all cryptographic checks have passed.
    replay_store.parent.mkdir(parents=True, exist_ok=True)
    lock = FileLock(str(replay_store.with_suffix(replay_store.suffix + ".lock")), timeout=10)
    try:
        with lock:
            store = read_json(replay_store) if replay_store.exists() else {"schema": "LAEV-HUC-REPLAY-STORE-1", "used_nonces": []}
            if store.get("schema") != "LAEV-HUC-REPLAY-STORE-1" or not isinstance(store.get("used_nonces"), list):
                raise ValueError("Replay store corrupto")
            nonce = original_payload.get("nonce")
            if nonce in store["used_nonces"]:
                raise ValueError("Challenge ya utilizado (replay detectado)")
            store["used_nonces"].append(nonce)
            # Keep bounded state; older expired entries are no longer replayable.
            if len(store["used_nonces"]) > 10000:
                store["used_nonces"] = store["used_nonces"][-5000:]
            write_json(replay_store, store)
    except Timeout as exc:
        raise TimeoutError("No se pudo bloquear el replay store") from exc
    return {"result": "VALID", "holder_proof_of_possession": True,
            "challenge_id": challenge["challenge_id"], "audience": expected_audience,
            "certificate_sha256_der": cert_digest, "credential_status": result["utxo_status"],
            "state_freshness_valid": result["state_freshness_valid"],
            "trust_anchor_sha256": result["trust_anchor_sha256"],
            "replay_protection": "nonce consumed"}


def _write_temp_bundle(raw: bytes, root: Path) -> Path:
    path = root / "credential-temp.zip"
    path.write_bytes(raw)
    return path


def audit(workspace: Path, expected_pin: str | None = None) -> dict[str, Any]:
    trust = load_trust(workspace, expected_pin)
    state = _ledger_state(workspace, trust)
    return {"ledger_integrity": "VALID", "event_count": state["event_count"],
            "active_certificates": len(state["active"]), "statuses": state["statuses"],
            "last_event_hash": state["last_event_hash"],
            "trust_anchor_sha256": trust["anchor_sha256"]}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LAEV HUC Standalone 0.7 — sin nodos ni blockchain")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--issuer-id", default="LAEV-HUC-ISSUER"); p.add_argument("--state-ttl-seconds", type=int, default=DEFAULT_STATE_TTL)
    p = sub.add_parser("request"); p.add_argument("--out-dir", type=Path, default=Path("./holder")); p.add_argument("--name", required=True)
    p = sub.add_parser("issue"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--csr", type=Path, required=True); p.add_argument("--days", type=int, default=365)
    p = sub.add_parser("renew"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--certificate", type=Path, required=True); p.add_argument("--csr", type=Path, required=True); p.add_argument("--days", type=int, default=365)
    p = sub.add_parser("revoke"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--certificate", type=Path, required=True); p.add_argument("--reason", required=True)
    p = sub.add_parser("refresh-status"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--certificate", type=Path, required=True)
    p = sub.add_parser("bundle"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--certificate", type=Path, required=True); p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("verify-bundle"); p.add_argument("--bundle", type=Path, required=True); p.add_argument("--trust-anchor-sha256", required=True); p.add_argument("--max-state-age-seconds", type=int, default=DEFAULT_STATE_TTL)
    p = sub.add_parser("challenge"); p.add_argument("--certificate-sha256", required=True); p.add_argument("--audience", required=True); p.add_argument("--ttl-seconds", type=int, default=120); p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("respond"); p.add_argument("--challenge", type=Path, required=True); p.add_argument("--bundle", type=Path, required=True); p.add_argument("--private-key", type=Path, required=True); p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("verify-response"); p.add_argument("--challenge", type=Path, required=True); p.add_argument("--response", type=Path, required=True); p.add_argument("--trust-anchor-sha256", required=True); p.add_argument("--audience", required=True); p.add_argument("--replay-store", type=Path, default=Path("./huc-replay-store.json")); p.add_argument("--max-state-age-seconds", type=int, default=DEFAULT_STATE_TTL)
    p = sub.add_parser("audit"); p.add_argument("--workspace", type=Path, default=Path("./huc-workspace")); p.add_argument("--trust-anchor-sha256", required=True)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "init": result = initialize(args.workspace, issuer_id=args.issuer_id, state_ttl_seconds=args.state_ttl_seconds)
        elif args.command == "request": result = generate_request(args.out_dir, args.name)
        elif args.command == "issue": result = issue(args.workspace, args.csr, args.days)
        elif args.command == "renew": result = renew(args.workspace, args.certificate, args.csr, args.days)
        elif args.command == "revoke": result = revoke(args.workspace, args.certificate, args.reason)
        elif args.command == "refresh-status": result = refresh_status(args.workspace, args.certificate)
        elif args.command == "bundle": result = export_bundle(args.workspace, args.certificate, args.output)
        elif args.command == "verify-bundle":
            result = verify_bundle(args.bundle, args.trust_anchor_sha256, args.max_state_age_seconds)
        elif args.command == "challenge": result = create_challenge(args.certificate_sha256, args.audience, args.output, args.ttl_seconds)
        elif args.command == "respond": result = respond_to_challenge(args.challenge, args.bundle, args.private_key, args.output)
        elif args.command == "verify-response":
            result = verify_response(args.challenge, args.response, args.trust_anchor_sha256,
                                     args.audience, args.replay_store, args.max_state_age_seconds)
        elif args.command == "audit": result = audit(args.workspace, args.trust_anchor_sha256)
        else: raise ValueError("Comando desconocido")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        if args.command == "verify-bundle" and not result.get("hybrid_valid"): return 1
        return 0
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
