# Changelog

## 0.7.0 — Standalone Certificate

- Nueva arquitectura sin nodos ni red de validadores.
- X.509 + HUC-CC complementario + UTXO lógico local.
- State Attestation firmada por el emisor con TTL.
- Paquete de verificación offline con pin externo.
- HUC Direct challenge-response opcional entre titular y aplicación.
- Prueba de posesión de clave, audiencia, nonce y protección contra replay.
- Emisión, renovación, revocación y actualización de atestaciones.
- Resultados VALID, INVALID e INDETERMINATE.
- Pruebas automatizadas y demostración pública sin claves privadas.
