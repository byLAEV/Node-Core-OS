import base64
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

import huc_standalone as huc


class StandaloneHUCTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.workspace = self.root / "issuer"
        init = huc.initialize(self.workspace, issuer_id="TEST-ISSUER", state_ttl_seconds=600)
        self.pin = init["trust_anchor_sha256"]
        self.holder_dir = self.root / "holder"
        req = huc.generate_request(self.holder_dir, "Standalone HUC Holder")
        self.csr = Path(req["csr_file"])
        self.private_key = Path(req["private_key_file"])
        self.issued = huc.issue(self.workspace, self.csr, 90)
        self.cert = Path(self.issued["certificate_file"])
        self.cc = Path(self.issued["consensus_certificate_file"])
        self.bundle = self.root / "active.zip"
        huc.export_bundle(self.workspace, self.cert, self.bundle)

    def tearDown(self):
        self.tmp.cleanup()

    def test_x509_huc_cc_and_utxo_offline_verification(self):
        result = huc.verify_bundle(self.bundle, self.pin)
        self.assertEqual(result["result"], "VALID")
        self.assertTrue(result["x509_signature_valid"])
        self.assertTrue(result["huc_cc_valid"])
        self.assertTrue(result["issuer_state_signature_valid"])
        self.assertEqual(result["utxo_status"], "ACTIVE")

    def test_wrong_external_trust_anchor_rejected(self):
        with self.assertRaisesRegex(ValueError, "huella externa"):
            huc.verify_bundle(self.bundle, "0" * 64)

    def test_tampered_cc_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with zipfile.ZipFile(self.bundle) as z:
                z.extractall(root)
            cc = json.loads((root / "consensus_certificate.json").read_text())
            cc["payload"]["consensus_mode"] = "FAKE"
            (root / "consensus_certificate.json").write_text(json.dumps(cc))
            bad = self.root / "bad-cc.zip"
            with zipfile.ZipFile(bad, "w", zipfile.ZIP_DEFLATED) as z:
                for path in root.iterdir():
                    z.write(path, path.name)
            with self.assertRaisesRegex(ValueError, "no coincide con package_manifest"):
                huc.verify_bundle(bad, self.pin)

    def test_tampered_state_attestation_signature_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with zipfile.ZipFile(self.bundle) as z:
                z.extractall(root)
            state = json.loads((root / "state_attestation.json").read_text())
            state["payload"]["status"] = "REVOKED"
            (root / "state_attestation.json").write_text(json.dumps(state))
            # Recompute the public manifest hash to get past packaging integrity,
            # then cryptographic issuer signature must still fail.
            manifest = json.loads((root / "package_manifest.json").read_text())
            manifest["state_attestation_sha256"] = huc.sha256((root / "state_attestation.json").read_bytes())
            (root / "package_manifest.json").write_text(json.dumps(manifest))
            bad = self.root / "bad-state.zip"
            with zipfile.ZipFile(bad, "w", zipfile.ZIP_DEFLATED) as z:
                for path in root.iterdir():
                    z.write(path, path.name)
            with self.assertRaisesRegex(ValueError, "Firma Ed25519 inválida"):
                huc.verify_bundle(bad, self.pin)

    def test_expired_status_proof_returns_indeterminate(self):
        from datetime import timedelta
        att_path = self.workspace / huc.CERT_DIR / f"state-{self.issued['certificate_sha256_der']}.json"
        att = huc.read_json(att_path)
        old = huc.now_utc() - timedelta(hours=2)
        att["payload"]["issued_at_utc"] = huc.iso(old)
        att["payload"]["expires_at_utc"] = huc.iso(old + timedelta(seconds=600))
        att["signature"] = huc._sign_ed(huc.load_private(self.workspace / huc.ISSUER_KEY), att["payload"])
        huc.write_json(att_path, att)
        cc = huc.read_json(self.cc)
        manifest = {
            "schema": huc.PACKAGE_SCHEMA,
            "version": huc.VERSION,
            "certificate_sha256_der": self.issued["certificate_sha256_der"],
            "consensus_certificate_sha256": huc.obj_hash(cc),
            "state_attestation_sha256": huc.sha256(att_path.read_bytes()),
            "private_keys_included": False,
        }
        stale_bundle = self.root / "stale.zip"
        with zipfile.ZipFile(stale_bundle, "w", zipfile.ZIP_DEFLATED) as archive:
            for path, arc in [
                (self.workspace / huc.CA_CERT, huc.CA_CERT),
                (self.workspace / huc.ISSUER_PUBLIC, huc.ISSUER_PUBLIC),
                (self.workspace / huc.POLICY_FILE, huc.POLICY_FILE),
                (self.workspace / huc.ANCHOR_FILE, huc.ANCHOR_FILE),
                (self.cert, "certificate.pem"),
                (self.cc, "consensus_certificate.json"),
                (att_path, "state_attestation.json"),
            ]:
                archive.write(path, arc)
            archive.writestr("package_manifest.json", json.dumps(manifest))
        result = huc.verify_bundle(stale_bundle, self.pin)
        self.assertEqual(result["result"], "INDETERMINATE")
        self.assertFalse(result["state_freshness_valid"])

    def test_renew_consumes_old_utxo_and_creates_new(self):
        renewal_holder = self.root / "holder-renewal"
        req = huc.generate_request(renewal_holder, "Standalone HUC Holder")
        renewed = huc.renew(self.workspace, self.cert, Path(req["csr_file"]), 90)
        new_bundle = self.root / "renewed.zip"
        old_bundle = self.root / "old-after-renewal.zip"
        huc.export_bundle(self.workspace, Path(renewed["certificate_file"]), new_bundle)
        huc.export_bundle(self.workspace, self.cert, old_bundle)
        self.assertEqual(huc.verify_bundle(new_bundle, self.pin)["result"], "VALID")
        old_check = huc.verify_bundle(old_bundle, self.pin)
        self.assertEqual(old_check["utxo_status"], "SUPERSEDED")
        self.assertEqual(old_check["result"], "INVALID")

    def test_revoke_produces_invalid_state(self):
        huc.revoke(self.workspace, self.cert, "key-compromise")
        revoked_bundle = self.root / "revoked.zip"
        huc.export_bundle(self.workspace, self.cert, revoked_bundle)
        result = huc.verify_bundle(revoked_bundle, self.pin)
        self.assertEqual(result["utxo_status"], "REVOKED")
        self.assertEqual(result["result"], "INVALID")

    def test_direct_challenge_response_and_replay_protection(self):
        challenge_path = self.root / "challenge.json"
        response_path = self.root / "response.json"
        huc.create_challenge(self.issued["certificate_sha256_der"], "hr.example.test", challenge_path)
        huc.respond_to_challenge(challenge_path, self.bundle, self.private_key, response_path)
        replay_store = self.root / "replays.json"
        verified = huc.verify_response(challenge_path, response_path, self.pin,
                                       "hr.example.test", replay_store)
        self.assertEqual(verified["result"], "VALID")
        self.assertTrue(verified["holder_proof_of_possession"])
        with self.assertRaisesRegex(ValueError, "replay"):
            huc.verify_response(challenge_path, response_path, self.pin,
                                "hr.example.test", replay_store)

    def test_direct_challenge_wrong_audience_rejected(self):
        challenge_path = self.root / "challenge-aud.json"
        response_path = self.root / "response-aud.json"
        huc.create_challenge(self.issued["certificate_sha256_der"], "payroll.example.test", challenge_path)
        huc.respond_to_challenge(challenge_path, self.bundle, self.private_key, response_path)
        with self.assertRaisesRegex(ValueError, "Audience incorrecta"):
            huc.verify_response(challenge_path, response_path, self.pin,
                                "other.example.test", self.root / "replay.json")

    def test_private_key_mismatch_cannot_respond(self):
        challenge_path = self.root / "challenge-mismatch.json"
        huc.create_challenge(self.issued["certificate_sha256_der"], "example.test", challenge_path)
        other = self.root / "other-holder"
        req = huc.generate_request(other, "Another Person")
        with self.assertRaisesRegex(ValueError, "no corresponde al certificado"):
            huc.respond_to_challenge(challenge_path, self.bundle,
                                     Path(req["private_key_file"]), self.root / "bad-response.json")

    def test_bundle_contains_no_private_keys(self):
        with zipfile.ZipFile(self.bundle) as z:
            names = z.namelist()
            self.assertFalse(any("private" in name.lower() or name.endswith(".key") for name in names))
            for name in names:
                data = z.read(name)
                self.assertNotIn(b"BEGIN " + b"PRIVATE KEY", data)

    def test_direct_response_signature_tampering_rejected(self):
        challenge_path = self.root / "challenge-tamper.json"
        response_path = self.root / "response-tamper.json"
        huc.create_challenge(self.issued["certificate_sha256_der"], "secure.example", challenge_path)
        huc.respond_to_challenge(challenge_path, self.bundle, self.private_key, response_path)
        response = huc.read_json(response_path)
        response["holder_signature_b64"] = base64.b64encode(b"x" * 64).decode("ascii")
        huc.write_json(response_path, response)
        with self.assertRaisesRegex(ValueError, "Prueba de posesión"):
            huc.verify_response(challenge_path, response_path, self.pin,
                                "secure.example", self.root / "tamper-replay.json")

    def test_ledger_event_signature_tampering_is_detected(self):
        ledger = self.workspace / huc.LEDGER_FILE
        event = json.loads(ledger.read_text().splitlines()[0])
        event["signature"] = base64.b64encode(b"x" * 64).decode("ascii")
        ledger.write_text(json.dumps(event) + "\n")
        with self.assertRaisesRegex(ValueError, "Ledger inválido"):
            huc.audit(self.workspace, self.pin)

    def test_two_concurrent_revocations_cannot_consume_same_utxo(self):
        from concurrent.futures import ThreadPoolExecutor
        def attempt(_):
            try:
                huc.revoke(self.workspace, self.cert, "concurrent-revoke")
                return "accepted"
            except ValueError:
                return "rejected"
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(attempt, range(2)))
        self.assertEqual(outcomes.count("accepted"), 1)
        self.assertEqual(outcomes.count("rejected"), 1)
        self.assertEqual(huc.audit(self.workspace, self.pin)["active_certificates"], 0)

    def test_revoke_updates_status_attestation(self):
        huc.revoke(self.workspace, self.cert, "revocation-test")
        refreshed = huc.refresh_status(self.workspace, self.cert)
        self.assertEqual(refreshed["status"], "REVOKED")
        self.assertEqual(huc.audit(self.workspace, self.pin)["active_certificates"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
