# Changelog — LAEV HUC

## 0.7.0

- TCP peer communication con sobres JSON firmados Ed25519 y caché anti-replay.
- Mensajes PING, PROPOSAL, COMMIT, VIEW_CHANGE_REQUEST, NEW_VIEW_CERTIFICATE, STATE_EXPORT/SYNC, MEMBERSHIP_PROPOSAL y MEMBERSHIP_STAGE.
- Peer map fijado por hash y asociado a la membresía activa.
- Servidor TCP con TLS opcional; binds fuera de loopback requieren TLS salvo override explícito para VPN/red privada de laboratorio.
- View Change conservador con mensajes firmados 2f+1, rotación determinista del proponente, preservación de un lock compatible y parada segura ante locks conflictivos.
- Membership Protocol con solicitud firmada de incorporación, quórum del comité anterior, checkpoint, distribución P2P a miembros retenidos y activación de la nueva época.
- Sincronización de estado por peer y continuidad de UTXO lógico después de reconfigurar la membresía.
- Demostración integrada: ISSUE, VIEW_CHANGE, RENEW, A→E membership handoff y REVOKE.

## 0.6.0

- Estado replicado con quórum 2f+1, bloqueo anti-equivocación y sincronización manual.

## 0.5.0

- Autoridades HUC-CC con claves independientes y flujo federado.

## 0.4.0

- Certificado complementario HUC-CC y validación conjunta X.509 + HUC-CC + UTXO.
