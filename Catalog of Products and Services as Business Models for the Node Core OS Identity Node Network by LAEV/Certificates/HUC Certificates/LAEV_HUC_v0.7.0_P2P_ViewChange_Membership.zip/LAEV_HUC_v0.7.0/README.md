# LAEV HUC 0.7.0 — P2P, recuperación y membresía federada

**HUC:** Hybrid UTXO Certificate  
**Protocolo de estado:** HUC-RSP/0.7  
**Componentes:** X.509 + HUC-CC + UTXO lógico + P2P + View Change + Membership  
**Estado:** prototipo funcional de laboratorio. No es una blockchain, criptomoneda ni una implementación BFT completa certificada para producción.

## Qué incorpora 0.7

HUC 0.7 elimina el intercambio manual de propuestas, votos y paquetes entre nodos en el flujo probado. Cada nodo ejecuta un servicio TCP que recibe mensajes autenticados mediante firmas Ed25519 de aplicación.

- **HUC Peer Communication:** mensajes directos entre nodos, ping, propuesta, voto, commit, cambio de vista, distribución de membresía y sincronización de estado.
- **HUC View Change:** mensajes de cambio de vista firmados, quórum 3-de-4, rotación determinista del proponente y recuperación conservadora de una única propuesta bloqueada.
- **HUC Membership:** solicitud de incorporación con prueba de posesión de la clave, propuesta de cambio de comité, aprobaciones del comité anterior, paquete de transición y checkpoint de estado.
- **HUC State Replication:** mantiene secuencia, hash de cabeza, commits y estados UTXO lógicos replicados.
- **HUC Certificate Validation:** en redes configuradas con CA y política HUC, cada validador comprueba el certificado X.509 y el HUC-CC antes de votar.

No se usan bloques, minería, token, criptomoneda ni comisión protocolaria. Persisten costes normales de alojamiento, conectividad y administración de nodos.

## Arquitectura

| Componente | Responsabilidad |
|---|---|
| X.509 | Identidad, clave pública, emisor, vigencia y firma del certificado |
| HUC-CC | Autorizaciones y política complementaria del certificado |
| HUC-RSP | Propuestas, votos, commits y estado replicado |
| HUC-Peer | Transporte TCP directo entre nodos y mensajes firmados |
| HUC-View | Cambio de vista y recuperación conservadora |
| HUC-Membership | Alta, retirada y cambio de época del comité |
| UTXO lógico | Estado consumible para ISSUE, RENEW y REVOKE |

## Requisitos

Python 3.10 o superior.

```bash
python -m pip install -r requirements.txt
```

En Android/Termux:

```bash
pkg update
pkg install python unzip
python -m pip install -r requirements.txt
```

Las dependencias externas son `cryptography` y `filelock`; el transporte utiliza `asyncio` de la biblioteca estándar de Python.

## Demostración integral reproducible

Desde la raíz del proyecto:

```bash
python demo/run_huc07.py
```

La demostración ejecuta servicios TCP sobre `127.0.0.1` con cuatro directorios de nodos y claves privadas independientes:

1. Emite un X.509 y su HUC-CC.
2. Propaga una propuesta ISSUE por TCP y obtiene votos de los cuatro validadores.
3. Apaga el proponente inicial A y solicita un cambio de vista; tres nodos firman y B pasa a ser el proponente de la nueva vista.
4. Renueva el certificado desde B usando la vista nueva.
5. Sustituye A por E mediante una propuesta de membresía: las autoridades actuales firman la transición y el paquete se distribuye a los nodos retenidos por P2P.
6. B, C y D activan la nueva época; E se incorpora con su propia clave privada y el checkpoint firmado.
7. La red renovada revoca el certificado nuevo.
8. Se comprueba que las cuatro réplicas terminan con la misma secuencia y hash de cabeza.

Los artefactos de revisión se guardan en `demo/huc07/public-artifacts/`. Las claves privadas de CA, titular y nodos se generan en un directorio temporal y no se copian a los artefactos públicos.

### Resultado esperado

```text
ISSUE              COMMITTED
VIEW_CHANGE        INSTALLED
RENEW              COMMITTED
MEMBERSHIP_HANDOFF ACTIVATED
REVOKE             COMMITTED
replicas_agree     true
```

## Pruebas automatizadas

```bash
python -m unittest discover -s tests -v
```

Las pruebas cubren el motor de certificados, estado replicado, firmas, anti-equivocación, transporte, replay, cambio de vista, transición de membresía, distribución P2P y sincronización.

## Despliegue manual: cuatro instituciones

### 1. Crear una identidad por institución

Cada institución ejecuta localmente, con un identificador distinto:

```bash
python huc_replicated.py node-init --id HUC-A --out-dir ./node-A
```

Cada participante conserva `node-private.pem`. Solo entrega `node-public.json`.

Repetir para HUC-B, HUC-C y HUC-D.

### 2. Crear y fijar el manifiesto de red

Un operador prepara el manifiesto inicial con los cuatro descriptores públicos:

```bash
python huc_replicated.py network-create \
  --validator-public ./node-A/node-public.json ./node-B/node-public.json \
                    ./node-C/node-public.json ./node-D/node-public.json \
  --fault-tolerance 1 \
  --ca-certificate ./issuer/ca_certificate.pem \
  --consensus-policy ./issuer/consensus_policy.json \
  --output ./network.json
```

El comando devuelve `network_sha256`. Todas las instituciones deben fijar esa huella por un canal independiente y confiable; no deben aceptar el manifiesto solo porque llegó de un peer.

Cada nodo se incorpora:

```bash
python huc_replicated.py join \
  --node-dir ./node-A --network ./network.json \
  --network-sha256 HUELLA_DE_RED
```

Repetir en cada nodo.

### 3. Configurar transporte P2P

Crear un mapa público de endpoints:

```bash
python huc_peer.py peer-map-create \
  --network ./network.json \
  --network-sha256 HUELLA_DE_RED \
  --endpoint HUC-A=10.10.0.11:8701 \
  --endpoint HUC-B=10.10.0.12:8701 \
  --endpoint HUC-C=10.10.0.13:8701 \
  --endpoint HUC-D=10.10.0.14:8701 \
  --output ./peer-map.json
```

Cada nodo instala el mapa fijando su propia huella:

```bash
python huc_peer.py peer-map-install \
  --node-dir ./node-A --peer-map ./peer-map.json \
  --peer-map-sha256 HUELLA_DEL_PEER_MAP
```

Repetir en cada nodo. El mapa asocia las identidades HUC con endpoints de red; debe distribuirse por canal autenticado y fijarse externamente.

### 4. Iniciar el servicio en cada institución

En la red real, configura TLS con un certificado de servidor cuyo SAN coincida con el nombre/IP anunciado y cuya CA sea confiada por los clientes:

```bash
python huc_peer.py serve \
  --node-dir ./node-A --bind-host 10.10.0.11 \
  --tls-cert ./tls/node-A.pem --tls-key ./tls/node-A.key
```

Los clientes usan `--tls-ca ./tls/network-ca.pem` en operaciones P2P. El prototipo permite el modo remoto sin TLS solo con una opción explícita; no se recomienda. Para laboratorio local se utiliza `127.0.0.1`.

### 5. Consultar peers

```bash
python huc_peer.py status --node-dir ./node-A --tls-ca ./tls/network-ca.pem
```

### 6. Crear y propagar propuesta

Primero crear X.509 + HUC-CC con `huc.py` y obtener:

- SHA-256 DER del X.509.
- SHA-256 del JSON canónico HUC-CC.

Preparar una propuesta y vincularla a la vista vigente:

```bash
python huc_replicated.py propose \
  --node-dir ./node-A --action ISSUE \
  --certificate-sha256 HASH_DER_X509 \
  --consensus-sha256 HASH_CANONICO_HUC_CC \
  --certificate ./certificate.pem \
  --consensus-certificate ./consensus.json \
  --output ./issue-raw.json

python huc_peer.py annotate-proposal \
  --node-dir ./node-A --proposal ./issue-raw.json \
  --output ./issue-proposal.json
```

Difundir la propuesta, reunir votos, formar el commit y transmitirlo:

```bash
python huc_peer.py broadcast-proposal \
  --node-dir ./node-A --proposal ./issue-proposal.json \
  --output-commit ./issue-commit.json \
  --tls-ca ./tls/network-ca.pem
```

### 7. Recuperar el proponente: View Change

Si A está fuera de servicio, B puede reunir mensajes firmados de cambio de vista:

```bash
python huc_peer.py advance-view \
  --node-dir ./node-B --output ./view-change.json \
  --reason unreachable-primary \
  --tls-ca ./tls/network-ca.pem
```

El certificado de vista se propaga a los pares disponibles. El nuevo proponente se determina de forma reproducible por el número de vista y la lista ordenada de validadores.

### 8. Incorporar o retirar una institución

La institución nueva crea su clave y solicitud de incorporación:

```bash
python huc_replicated.py node-init --id HUC-E --out-dir ./node-E
python huc_membership.py join-request \
  --node-dir ./node-E --network ./network.json \
  --output ./join-E.json
```

Un miembro actual propone la sustitución de A por E (mantiene cuatro miembros y `n=3f+1`):

```bash
python huc_membership.py propose \
  --node-dir ./node-B \
  --join-request ./join-E.json \
  --remove-validator HUC-A \
  --output ./membership-proposal.json
```

Difundir por TCP, obtener firmas del comité anterior y depositar el paquete en los nodos que permanecen:

```bash
python huc_peer.py broadcast-membership-proposal \
  --node-dir ./node-B \
  --proposal ./membership-proposal.json \
  --output-package ./membership-package.json \
  --tls-ca ./tls/network-ca.pem
```

Los nodos retenidos activan el paquete:

```bash
python huc_membership.py activate \
  --node-dir ./node-B --package ./membership-package.json
```

El nuevo miembro se incorpora con su propia clave:

```bash
python huc_membership.py join-successor \
  --node-dir ./node-E --package ./membership-package.json
```

El miembro entrante está fuera de la red antigua, por lo que el paquete certificado se entrega mediante una invitación/canal de enrolamiento autenticado. Los miembros retenidos reciben el paquete automáticamente por P2P. El nodo retirado no puede activar la red sucesora.

### 9. Sincronizar estado desde un peer

```bash
python huc_peer.py sync-from-peer \
  --node-dir ./node-D --peer-id HUC-B \
  --tls-ca ./tls/network-ca.pem
```

El nodo receptor verifica la red, el checkpoint, los commits y que no haya rollback o fork.

## Modelo de quórum y membresía

El perfil de laboratorio es `n=3f+1`, `q=2f+1`. Para cuatro validadores: `f=1`, quórum 3. La reconfiguración de membresía conserva la regla: cuatro, siete, diez miembros, etc. No se puede añadir un único validador a un comité de cuatro sin una transición a una cardinalidad permitida; la demostración reemplaza A por E y mantiene cuatro.

## Limitaciones críticas

- Los sockets y la demostración se probaron sobre TCP loopback. No se ha validado aún el funcionamiento entre instituciones reales, a través de Internet, NAT, firewalls o enlaces inestables.
- No hay descubrimiento automático, NAT traversal, relay ni retransmisión de peers. La dirección de cada nodo se configura en un peer map.
- La firma Ed25519 de aplicación autentica mensajes, pero no cifra el canal. En redes no confiables se requiere TLS o VPN. El servidor exige TLS para enlazar a una dirección no loopback salvo una excepción explícita de laboratorio/VPN.
- View Change 0.7 es conservador: cambia el proponente con certificado firmado, preserva una única propuesta bloqueada y detiene el avance si detecta locks incompatibles. No es PBFT/HotStuff completo ni una prueba formal de tolerancia bizantina.
- La membresía requiere aprobación del comité anterior. El nuevo miembro recibe el paquete por un canal de invitación autenticado, porque todavía no pertenece a la red que puede transmitirlo.
- No se implementa una política formal de revocación de claves de validadores ni recuperación segura de HSM.
- Un verificador offline no puede conocer una revocación posterior a su último checkpoint.
- Las claves privadas de los nodos y la CA deben protegerse con almacenamiento seguro; este prototipo de demo no reemplaza HSM/KMS.

Consulte `PROTOCOL.md`, `ARCHITECTURE.md` y `SECURITY.md`. No utilizar en producción ni para TLS público sin revisión externa de seguridad y pruebas de despliegue.
