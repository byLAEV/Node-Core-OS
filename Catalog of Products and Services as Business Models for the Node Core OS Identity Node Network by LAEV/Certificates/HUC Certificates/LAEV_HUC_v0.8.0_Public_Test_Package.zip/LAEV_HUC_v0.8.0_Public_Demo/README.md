# LAEV HUC 0.8.0 — BFT consensus, prepared certificates and recovery

**HUC:** Hybrid UTXO Certificate  
**State protocol:** HUC-RSP/0.6 + HUC-BFT/0.8  
**Components:** X.509 + HUC-CC + logical UTXO + independent validators + TCP/TLS peer transport + BFT-inspired phases + prepared certificates + view change + state sync  
**Status:** experimental laboratory implementation. It is not a blockchain, cryptocurrency, formally verified BFT implementation, or production-certified PKI.

## What 0.8 adds

HUC 0.8 adds a BFT-inspired consensus layer to the HUC replicated-state and P2P base:

- **PRE-PREPARE:** the primary for the current view proposes one operation against a specific parent-state hash and sequence.
- **PREPARE:** each validator verifies the proposal and signs the exact PRE-PREPARE identity. A `PrepareCertificate` collects a quorum of matching votes.
- **Prepared lock:** validators persist a per-sequence anti-equivocation lock and sign a lock acknowledgement. A `PreparedCertificate` combines the `PrepareCertificate` with a quorum of lock acknowledgements.
- **COMMIT:** validators verify the prepared certificate, sign COMMIT and assemble a `CommitCertificate` with quorum.
- **Apply:** every replica independently verifies the commit certificate and the X.509/HUC-CC evidence before applying the UTXO transition.
- **View change:** signed `VIEW_CHANGE` messages carry committed checkpoints and prepared evidence. A `NEW_VIEW` certificate selects the highest prepared request and the new primary reproposes it.
- **BFT state export/sync:** a node can export a public state package; another node verifies the entire commit and view-change history before syncing. Rollback, forks and altered evidence are rejected.
- **P2P orchestration:** the phases, view change, recovery and sync can be transported over TCP. For non-loopback connections use TLS; application messages are independently authenticated with validator Ed25519 signatures.
- **PKI integration:** validators can verify the actual X.509 certificate and HUC-CC document before voting.

For four validators the configuration is `n = 3f + 1`, `f = 1` and quorum `2f + 1 = 3`. This is the classical PBFT-style fault model. The implementation includes an additional prepared-lock acknowledgement stage to make lock evidence explicit in this HUC profile.

## Architecture

| Component | Responsibility |
|---|---|
| X.509 | Subject identity, public key, issuer, validity and CA signature |
| HUC-CC | Complementary authorization and consensus certificate |
| HUC-UTXO | Logical state outputs and ISSUE/RENEW/REVOKE transitions |
| HUC-BFT | PRE-PREPARE, PREPARE, prepared certificate, COMMIT, view change and recovery |
| HUC-Peer | TCP peer messages, TLS transport and Ed25519 application authentication |
| HUC State Sync | Verified commit history and view-certificate synchronization |

There is no blockchain, mining, token, cryptocurrency or protocol payment. Nodes still incur ordinary infrastructure, connectivity and operational costs.

## Requirements

- Python 3.10 or later.
- Dependencies: `cryptography` and `filelock`.

```bash
python -m pip install -r requirements.txt
```

Android/Termux:

```bash
pkg update
pkg install python openssl
python -m pip install -r requirements.txt
```

## Run the complete automated test suite

From the project root:

```bash
python -m unittest discover -s tests -v
```

Expected final summary for this release:

```text
Ran 90 tests
OK
```

The tests include state-machine checks, malformed/tampered messages, insufficient quorum, duplicate and replayed votes, equivocation attempts, conflicting prepared certificates, partition below quorum, prepared recovery after primary failure, rollback/fork rejection, PKI validation by every validator, and a TLS TCP cluster made of four independent Python processes.

## Reproduce the four-process TLS cluster test

The integration test is:

```bash
python -m unittest tests.test_bft_process_cluster -v
```

It creates four independent node directories and four separate server processes, uses TLS certificates, executes a BFT round over TCP and checks that all four replicas have the same sequence and state head. The processes run on one test host using loopback addresses. This is a multi-process network test, **not a test on four physical devices**.

## Core BFT commands

Initialize BFT state on an already enrolled replicated node:

```bash
python huc_bft.py init --node-dir ./node-A
```

Create a proposal. When the network has PKI enabled, attach the actual X.509 and HUC-CC files:

```bash
python huc_bft.py propose \
  --node-dir ./node-A \
  --action ISSUE \
  --certificate-sha256 CERTIFICATE_DER_SHA256 \
  --consensus-sha256 HUC_CC_CANONICAL_JSON_SHA256 \
  --certificate ./certificate.pem \
  --consensus-certificate ./consensus_certificate.json \
  --output ./proposal.json
```

Run PRE-PREPARE/PREPARE/PREPARED/COMMIT over P2P and collect the commit certificate:

```bash
python huc_bft_peer.py broadcast \
  --node-dir ./node-A \
  --proposal ./proposal.json \
  --output-commit ./commit-certificate.json \
  --tls-ca ./tls/network-ca.pem
```

When the primary is unavailable, collect and install a new view:

```bash
python huc_bft_peer.py advance-view \
  --node-dir ./node-B \
  --output ./new-view-certificate.json \
  --reason primary-unreachable \
  --tls-ca ./tls/network-ca.pem
```

If that new view includes a prepared request, recover it:

```bash
python huc_bft_peer.py recover \
  --node-dir ./node-B \
  --output-commit ./recovered-commit.json \
  --tls-ca ./tls/network-ca.pem
```

Synchronize a restarted/stale node from an authenticated peer:

```bash
python huc_bft_peer.py sync \
  --node-dir ./node-A \
  --peer-id HUC-B \
  --tls-ca ./tls/network-ca.pem
```

Inspect local sequence, view and head:

```bash
python huc_bft.py status --node-dir ./node-A
```

## Physical-device test

See [PHYSICAL_DEVICE_TEST.md](PHYSICAL_DEVICE_TEST.md). It covers four actual computers/phones, private network/VPN addressing, TLS server certificates, firewall rules, peer maps, BFT broadcast, failure injection, view change and state synchronization.

The physical-device procedure is supplied but has **not** been executed by this development environment. Do not interpret the four-process loopback TLS test as proof of WAN/NAT/physical-device interoperability.

## Safety model and limits

This is a PBFT-inspired HUC prototype, not a formally verified implementation of the complete PBFT protocol. The implementation has PRE-PREPARE, PREPARE quorum, prepared-lock quorum, COMMIT quorum, signed view-change certificates and recovery selection. A shared persistent file lock serializes local read/check/sign/write sequences for consensus votes and view changes; a concurrency regression test checks that one replica cannot double-sign conflicting PRE-PREPAREs for the same slot. It has not undergone an independent cryptographic audit, formal verification, fuzzing campaign or production-scale adversarial deployment.

- For four replicas, the intended model tolerates at most one Byzantine validator if the quorum, persistence and cryptographic assumptions hold.
- A partition leaving fewer than three validators cannot commit; HUC stops rather than accepting conflicting writes.
- Local durable locks reduce equivocation, but production needs hardened storage, safe backups, HSM/KMS and rollback-resistant checkpoints.
- The test TLS CA and server certificates are generated only for local integration tests. Real deployments need institutionally managed TLS certificates, correct SANs and trusted CA distribution. Peer message signatures authenticate HUC identities at the application layer; the current peer server does not require mutual TLS client certificates.
- No NAT traversal, relay/discovery service, automatic peer discovery, monitoring, rate limiting or operational SLA is included.
- Offline verification cannot discover a revocation created after the last state checkpoint received.
- X.509/HUC-CC signatures prove cryptographic authorization, not a person's civil identity or the legal authority of an institution.

Before production: formal protocol review, independent security audit, external interoperability testing, property-based tests/fuzzing, tested device/network deployment, key custody, operational runbooks and legal/privacy review are required.

## References

- Miguel Castro and Barbara Liskov, *Practical Byzantine Fault Tolerance*, OSDI 1999: https://www.usenix.org/conference/osdi-99/practical-byzantine-fault-tolerance
- HUC's protocol is PBFT-inspired and has additional HUC-specific prepared-lock evidence. It should not be treated as equivalent to a formally verified PBFT implementation.
