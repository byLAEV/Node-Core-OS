# Demostraciones LAEV HUC

- `replicated-state/`: demostración principal de HUC 0.6 con cuatro validadores independientes, quórum 3/4, X.509 + HUC-CC y transiciones ISSUE/RENEW/REVOKE replicadas.
- `run_replicated_state.py`: reconstruye la demostración desde cero; crea claves solo en un directorio temporal y exporta artefactos públicos.
- `run_replicated_state.sh`: wrapper para ejecutar el script Python.
- Los paquetes `huc-demo-*.zip` heredados corresponden a pruebas de certificados de versiones previas.

No se incluyen claves privadas en los artefactos de demostración.
