# Changelog

## 0.6.0

- Nuevo HUC-RSP: estado UTXO lógico replicado mediante quórums, sin coordinador fijo.
- Perfil estático `n=3f+1`, `q=2f+1`; cuatro validadores y tres votos para `f=1`.
- Nodos generan y custodian claves Ed25519 locales.
- Cualquier nodo puede proponer, votar, ensamblar commits y aplicar.
- Anti-equivocación persistente: un voto por `epoch:sequence`.
- Certificados de commit verificables por todas las réplicas.
- Sincronización de ledger con rechazo de rollback y forks.
- Perfil PKI integrado: cada validador verifica X.509 y HUC-CC antes de votar.
- Verificador local X.509 + HUC-CC + estado replicado.
- Demostración real con emisión, renovación, revocación y una réplica que se sincroniza desde un par.
- Aclaración explícita: no es aún BFT completo; no hay view-change ni transporte P2P automático.

## 0.5.0

- Claves privadas HUC-CC de autoridades independientes.
- Propuestas, aprobaciones y sincronización fuera de banda.
- Quórum HUC-CC 2-de-3.

## 0.4.0

- Certificado X.509, HUC-CC complementario y registro UTXO lógico.
