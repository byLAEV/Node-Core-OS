# LAEV HUC 0.6.0 — Leaderless Replicated State

**HUC = Hybrid UTXO Certificate**  
**Nuevo componente:** HUC-RSP (Replicated State Protocol)  
**Arquitectura:** X.509 + HUC-CC + estado UTXO replicado mediante certificados de quórum.  
**Estado:** prototipo de laboratorio funcional; todavía no es un BFT completo ni una red P2P automática.

## Qué cambia en 0.6

La versión 0.5 separaba las claves privadas de las autoridades, pero el coordinador seguía preparando el orden final del ledger. HUC 0.6 elimina ese rol fijo:

- Cuatro nodos independientes forman el perfil inicial `n=3f+1`, `f=1`.
- Se requieren tres votos Ed25519 distintos (`2f+1`) para confirmar una transición.
- Cualquier participante puede proponer una operación.
- Cada nodo valida y firma desde su propio almacén de claves.
- Cualquier nodo puede reunir las firmas y ensamblar un certificado de commit.
- Cada réplica aplica localmente el commit y conserva el mismo historial verificable.
- Un nodo atrasado puede sincronizarse desde cualquier par sin confiar en un único servidor.
- No hay blockchain, minería, token ni comisión por transacción.

**Precisión:** esto es un protocolo de estado replicado con certificados de quórum y bloqueo anti-equivocación, no una implementación completa de PBFT/HotStuff. No hay view-change ni recuperación automática de un slot bloqueado. Consulta `PROTOCOL.md` y `SECURITY.md` antes de evaluar el modelo de confianza.

## Componentes

| Componente | Función |
|---|---|
| X.509 | Identidad, clave pública, emisor, vigencia y firma |
| HUC-CC | Certificado complementario de autorización/consenso del certificado |
| HUC-RSP | Acuerdo por quórum y replicación del estado entre nodos |
| UTXO lógico | Salidas de estado; ISSUE crea, RENEW consume/crea, REVOKE consume |
| Verificador de nodo | Comprueba X.509, HUC-CC y estado replicado local |

En redes creadas con CA y política HUC-CC, cada validador comprueba el contenido del certificado X.509 y el documento HUC-CC antes de votar. El perfil genérico sin CA/política solo prueba replicación de hashes y no se recomienda para certificados HUC reales.

## Instalación

Python 3.10+ recomendado. En Termux:

```bash
pkg update
pkg install python unzip
python -m pip install -r requirements.txt
```

## Ejecutar la demostración integral

Desde la raíz del proyecto:

```bash
python demo/run_replicated_state.py
```

El script genera temporalmente:

1. Una CA y un certificado X.509 real de demostración.
2. Un HUC-CC firmado por el umbral de autoridades de la política demo.
3. Cuatro nodos RSP con cuatro claves Ed25519 distintas.
4. Una red 4/3: cuatro validadores, quórum de tres.
5. Una emisión aprobada por A+B+C.
6. Una sincronización en la que D se mantiene sin aplicar el commit hasta recibir un paquete de A.
7. Una renovación aprobada por A+B+D.
8. Una revocación aprobada por B+C+D.
9. Comprobación de que las cuatro réplicas terminan con la misma secuencia y hash de cabeza.

Las claves privadas se generan dentro de un directorio temporal y se eliminan al terminar. Los artefactos públicos de revisión quedan en `demo/replicated-state/`.

También puedes ejecutar:

```bash
python -m unittest discover -s tests -v
```

## Flujo manual con cuatro instituciones

### 1. Cada institución crea su nodo local

En cada dispositivo/servidor, cambia el ID y el directorio:

```bash
python huc_replicated.py node-init --id INSTITUTION-A --out-dir ./node-A
```

Entrega al administrador de red únicamente `node-public.json`. Nunca copies `node-private.pem`.

Repite para B, C y D. Las cuatro claves privadas permanecen en los cuatro equipos.

### 2. Crear la red pública y fijar su huella

El administrador combina los cuatro descriptores públicos y fija la CA y política HUC-CC que todos deberán confiar:

```bash
python huc_replicated.py network-create \
  --validator-public ./node-A/node-public.json ./node-B/node-public.json \
                    ./node-C/node-public.json ./node-D/node-public.json \
  --fault-tolerance 1 \
  --ca-certificate ./issuer/ca_certificate.pem \
  --consensus-policy ./issuer/consensus_policy.json \
  --output ./network.json
```

El comando imprime `network_sha256`. Distribuye `network.json` y comunica ese pin por un canal independiente (por ejemplo, presencial o un canal institucional autenticado).

### 3. Cada nodo se une a la misma red

En cada dispositivo:

```bash
python huc_replicated.py join \
  --node-dir ./node-A \
  --network ./network.json \
  --network-sha256 HUELLA_DE_RED
```

Repite en B, C y D.

### 4. Emitir X.509 + HUC-CC

Usa el emisor HUC para producir el certificado y su documento complementario. Para una demostración local:

```bash
python huc.py init --workspace ./issuer --threshold 2 --authorities 3
python huc.py request --out-dir ./holder --name "HUC Holder"
python huc.py issue --workspace ./issuer --csr ./holder/RUTA.csr.pem --days 365
```

En un despliegue real, configura las claves públicas de las autoridades HUC-CC con `huc.py init --authority-public ...` y utiliza el flujo federado de `huc_federation.py` para que las claves privadas de esas autoridades permanezcan separadas.

Calcula el hash canónico del HUC-CC:

```bash
python -c 'import json,huc,sys; x=json.load(open(sys.argv[1])); print(huc.sha256(huc.canonical_json(x)))' RUTA_CONSENSUS.json
```

El resultado X.509 incluye `certificate_sha256_der`.

### 5. Crear una propuesta (cualquier nodo)

```bash
python huc_replicated.py propose \
  --node-dir ./node-D \
  --action ISSUE \
  --certificate-sha256 HASH_DER_X509 \
  --consensus-sha256 HASH_CANONICO_HUC_CC \
  --certificate ./certificate.pem \
  --consensus-certificate ./consensus.json \
  --output ./issue-proposal.json
```

La propuesta contiene el certificado público y HUC-CC. Cada validador vuelve a comprobarlos de forma independiente.

### 6. Cada institución vota desde su propio equipo

```bash
python huc_replicated.py vote --node-dir ./node-A --proposal ./issue-proposal.json --output ./vote-A.json
```

Repite en B, C o D hasta obtener tres firmas distintas. El nodo bloquea de forma persistente su voto para ese `epoch:sequence` y rechaza una segunda propuesta incompatible.

### 7. Cualquier nodo ensambla y replica el commit

Cualquier participante puede reunir las firmas; no existe un coordinador privilegiado:

```bash
python huc_replicated.py commit \
  --node-dir ./node-B \
  --proposal ./issue-proposal.json \
  --vote ./vote-A.json ./vote-B.json ./vote-C.json \
  --output ./issue.commit.json
```

Cada réplica lo aplica localmente:

```bash
python huc_replicated.py apply --node-dir ./node-A --commit ./issue.commit.json
```

Repite en las demás instituciones.

### 8. Sincronizar un nodo atrasado

Cualquier par exporta un paquete de estado público:

```bash
python huc_replicated.py export-state --node-dir ./node-A --output ./state.zip
```

El nodo atrasado verifica el historial y lo sincroniza:

```bash
python huc_replicated.py sync-state --node-dir ./node-D --package ./state.zip
```

Se rechazan rollback y bifurcaciones respecto del historial local.

### 9. Verificar X.509 + HUC-CC + estado replicado

```bash
python huc_replicated.py verify-certificate \
  --node-dir ./node-A \
  --certificate ./certificate.pem \
  --consensus-certificate ./consensus.json
```

El resultado será `VALID`, `INVALID` o `INDETERMINATE` según firma, política y estado local.

Para renovar, crea un certificado/HUC-CC nuevo y propone `RENEW` con `--previous-certificate-sha256`. Para revocar, propone `REVOKE`, suministra el certificado y su HUC-CC vigente y agrega `--metadata '{"reason":"..."}'`.

## Archivos importantes

- `huc_replicated.py`: protocolo RSP 0.6, nodos, propuestas, votos, commits, aplicación y sincronización.
- `huc.py`: X.509 + HUC-CC + UTXO lógico del prototipo anterior.
- `huc_federation.py`: flujo de autoridades HUC-CC independientes de la versión 0.5.
- `PROTOCOL.md`: reglas y supuestos del protocolo.
- `ARCHITECTURE.md`: componentes y flujo.
- `SECURITY.md`: amenazas, límites y requisitos previos a producción.
- `demo/replicated-state/`: artefactos públicos generados por la demostración.

## Estado y límites

- No hay líder ni coordinador fijo. El proponente y el nodo que ensambla un commit son funciones no privilegiadas que puede asumir cualquier participante.
- Hay membresía estática. Agregar/quitar validadores requiere un procedimiento de gobernanza posterior.
- El transporte es intercambio de paquetes; no hay socket, relay, P2P ni descubrimiento automático.
- Una división 2/2 puede detener el slot. Esta versión no implementa view-change/recovery automática.
- La red 4/3 tolera una falla bizantina para la seguridad bajo las hipótesis de `PROTOCOL.md`; no ofrece liveness frente a cualquier combinación de fallas.
- Las claves privadas se almacenan sin contraseña en este prototipo. No usar con autoridades reales en producción.
- El ancla y el manifiesto de red deben fijarse fuera de banda.
- El verificador desconectado solo conoce el último estado recibido; no puede detectar una revocación posterior hasta sincronizarse.

HUC 0.6 demuestra replicación y quórum sin blockchain. Para producción necesita view-change formal, revisión criptográfica externa, HSM/KMS, RFC 8785/JCS interoperable, timestamps confiables, políticas de identidad, transporte seguro y pruebas de red real.
