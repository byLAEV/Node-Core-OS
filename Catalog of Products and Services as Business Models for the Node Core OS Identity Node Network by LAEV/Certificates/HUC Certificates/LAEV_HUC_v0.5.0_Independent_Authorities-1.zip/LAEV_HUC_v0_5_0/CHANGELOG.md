# Changelog

## 0.5.0

- Añadido flujo de autoridades independientes con generación de claves Ed25519 por dispositivo.
- Inicialización del workspace a partir de descriptores públicos; el coordinador no recibe claves privadas de autoridad.
- Añadidos paquetes públicos de enrolamiento y sincronización de estado.
- Añadidas propuestas firmables para ISSUE, RENEW y REVOKE.
- Cada aprobación firma el ID de propuesta, la transición UTXO y el payload HUC-CC cuando aplica.
- Añadido rechazo de propuestas obsoletas, aprobaciones duplicadas y sincronizaciones con rollback/bifurcación.
- Añadido bloqueo local anti-equivocación para que una autoridad no firme dos propuestas incompatibles en el mismo checkpoint mientras estén vigentes.
- Añadida prueba integral de tres autoridades independientes, ciclo ISSUE/REVOKE y sincronización.


## 0.4.0

- Añadido HUC-CC como certificado complementario independiente firmado por múltiples autoridades.
- Vinculación de HUC-CC con el hash DER X.509 y el outpoint UTXO inicial.
- Política de consenso configurable; perfil de demostración 2-de-3 Ed25519.
- Las transiciones ISSUE, RENEW y REVOKE requieren firmas del quórum y firma del registro.
- Añadido verificador unificado y paquetes públicos verificables offline.
- Añadidos escenarios ACTIVE, RENEWED ACTIVE, SUPERSEDED y REVOKED.
- Añadidas pruebas de umbral, manipulación, vinculación errónea, pin externo y doble consumo concurrente.
