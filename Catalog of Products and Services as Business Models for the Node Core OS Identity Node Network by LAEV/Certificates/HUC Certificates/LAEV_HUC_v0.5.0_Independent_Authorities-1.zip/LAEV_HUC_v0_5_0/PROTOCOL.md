# LAEV HUC — especificación de referencia 0.5.0

## 1. Objetivo

Vincular tres objetos que funcionan en paralelo:

- X.509: certificado de identidad/atributos.
- HUC-CC: certificado complementario de consenso, emitido como JSON firmado.
- HUC-UTXO: registro lógico de estados y transiciones.

HUC-CC referencia al certificado X.509 mediante SHA-256 del DER y al estado UTXO mediante un outpoint `{txid, vout}`. X.509 permanece intacto y puede consumirse mediante PKI tradicional.

## 2. Roles de clave

1. CA RSA-3072: firma certificados X.509.
2. Titular RSA-2048+: genera su clave y firma el CSR.
3. Autoridades Ed25519: firman políticas de emisión, renovación y revocación; el perfil de demostración utiliza 2 de 3.
4. Registro Ed25519: firma el hash del evento serializado del ledger.

En el paquete de laboratorio las claves de autoridad están bajo un solo workspace. Una implementación federada debe separar físicamente o mediante HSM/KMS la custodia de cada autoridad.

## 3. HUC-CC

`consensus_certificate.json` contiene:

- `type`: `LAEV-HUC-CC`.
- `version`: versión del formato HUC-CC.
- `payload.certificate_sha256_der`: hash DER del X.509.
- `payload.initial_utxo_outpoint`: salida generada por ISSUE o RENEW.
- `payload.utxo_sequence_at_issuance`: secuencia de evento que creó la salida.
- `payload.policy_sha256`: hash de la política de consenso aplicable.
- `payload.threshold` y `payload.authority_count`: quórum esperado.
- `payload.operation`: ISSUE o RENEW.
- `payload.authorized_state_at_issuance`: ACTIVE.
- `signatures`: firmas Ed25519 de autoridades distintas.

El certificado complementario no es otro X.509. Es un objeto de evidencia HUC independiente con firma múltiple y formato versionado.

## 4. Política de consenso

`consensus_policy.json` define la lista de autoridades, claves públicas, permisos y umbral. La política queda fijada en `trust_anchor.json`. El verificador requiere un pin SHA-256 del ancla obtenido por un canal independiente.

Para el MVP, el perfil es 2-de-3. `ISSUE`, `RENEW` y `REVOKE` requieren dos firmas válidas de autoridades con el permiso correspondiente.

## 5. Estado UTXO lógico

Un outpoint es `{ "txid": <64 hex>, "vout": 0 }`.

| Operación | Entrada consumida | Salida nueva | Estado resultante |
|---|---|---|---|
| ISSUE | Ninguna | Sí | ACTIVE |
| RENEW | UTXO activo anterior | Sí | Anterior SUPERSEDED; nuevo ACTIVE |
| REVOKE | UTXO activo | No | REVOKED |

El estado se reconstruye reproduciendo la secuencia de eventos del ledger. No se borra el historial.

## 6. Firma y hashes

Cada evento contiene un payload. `txid` es SHA-256 del payload excluyendo `output`; `output.txid` referencia ese `txid`. `event_hash` es SHA-256 del payload completo. En el perfil local, dos o más autoridades firman el payload directamente. En el perfil federado 0.5, cada autoridad firma desde su dispositivo y el archivo de aprobación contiene firma de propuesta, transición y HUC-CC; el finalizador verifica y coloca las firmas de transición/HUC-CC en sus respectivos objetos. La clave del registro firma los bytes de `event_hash`.

HUC 0.5 mantiene el perfil restringido de JSON canónico a claves ASCII, enteros seguros, sin flotantes, UTF-8, claves ordenadas y sin espacios separadores. Esta es una regla de perfil del prototipo, no una declaración de compatibilidad completa con RFC 8785. Para producción debe utilizarse una implementación JCS interoperable y vectores de prueba RFC 8785.

## 7. Validación

`hybrid_valid = true` solamente cuando:

1. X.509 está firmado por la CA fijada en el ancla.
2. X.509 y CA están dentro de su vigencia.
3. HUC-CC está firmado por el umbral de autoridades autorizadas.
4. HUC-CC referencia el hash exacto del X.509.
5. HUC-CC referencia el outpoint y secuencia de la transición de emisión.
6. La política de HUC-CC coincide con la política fijada en el ancla.
7. El ledger está íntegro y todas sus transiciones tienen firmas válidas.
8. El estado actual del certificado es ACTIVE y existe una salida UTXO no consumida.
9. La huella externa del ancla coincide.

Si el certificado se encuentra revocado o sustituido, el resultado es inválido para uso actual, aunque el documento y la firma X.509 sigan siendo criptográficamente auténticos.

## 8. Alcance

Este perfil demuestra certificados paralelos, aprobación multiinstitucional con claves independientes y validación criptográfica con firmas múltiples. No implementa consenso BFT distribuido, replicación P2P, OCSP/CRL, timestamp de tercero, protección de claves por hardware ni resolución de conflictos entre operadores independientes.


## Extensión federada 0.5 — aprobaciones independientes

El perfil federado separa las claves privadas de autoridad de la infraestructura coordinadora. Cada autoridad crea su clave Ed25519 en su propio entorno; el workspace HUC recibe únicamente su descriptor público. Las propuestas incluyen un checkpoint del ledger, un payload de transición y, para ISSUE/RENEW, un payload HUC-CC. Cada autoridad firma el identificador de la propuesta y ambos payloads aplicables.

El coordinador valida las firmas y el umbral, vuelve a comprobar el checkpoint bajo bloqueo local y finaliza la transición. Las autoridades solo aprueban propuestas cuyo checkpoint coincide con el ledger público que tienen sincronizado. La sincronización admite únicamente extensiones append-only del historial local y rechaza rollback o bifurcaciones.

Este mecanismo implementa autorización multiinstitucional con claves separadas y sincronización verificable. No es consenso BFT: el coordinador sigue siendo responsable de la secuencia/finalización del registro y no existe una réplica de consenso sin líder central.

### Bloqueo local anti-equivocación

El dispositivo de cada autoridad conserva `approval-locks.json`, indexado por hash del checkpoint `{event_count, last_event_hash}`. Una autoridad no firma otro `proposal_id` para el mismo checkpoint mientras la propuesta anterior esté vigente. Un paquete de sincronización válido que extiende el ledger libera los bloqueos de checkpoints superados. El vencimiento de la propuesta hace que la aprobación antigua deje de ser finalizable por el coordinador. Este mecanismo ayuda a evitar firmas incompatibles accidentales; no protege frente a compromiso del dispositivo ni sustituye un consenso BFT replicado.
