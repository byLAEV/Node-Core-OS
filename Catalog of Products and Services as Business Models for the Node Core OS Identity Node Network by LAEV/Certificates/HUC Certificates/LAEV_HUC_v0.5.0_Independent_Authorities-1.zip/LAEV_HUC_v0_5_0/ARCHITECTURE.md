# Arquitectura LAEV HUC 0.5.0

```text
          CERTIFICADO X.509
      (identidad + clave pública)
                  |
           SHA-256 del DER
                  |
                  v
       HUC-CC COMPLEMENTARIO
   (2-de-3 autoridades Ed25519)
         |                |
   hash política      outpoint UTXO
         |                |
         +--------+-------+
                  v
        HUC-UTXO STATE LOG
  ISSUE -> RENEW -> REVOKE; eventos
  encadenados y firmados por el registro
                  |
                  v
          HUC UNIFIED VERIFIER
   X.509 + HUC-CC + política + UTXO
```

## Separación de responsabilidades

- **X.509:** certificado estándar de identidad/atributos firmado por la CA.
- **HUC-CC:** objeto JSON firmado de forma múltiple que atestigua que un grupo de autoridades aprobó la emisión bajo una política identificada y para un outpoint concreto.
- **HUC-UTXO:** registro de estado lógico. Conserva transiciones e impide que el mismo outpoint se consuma dos veces dentro del registro local.
- **Trust anchor:** enlaza CA, clave del registro y política; su huella se distribuye por canal independiente.
- **Verificador:** aplica una regla conjunta y devuelve VALID o INVALID según el estado actual incluido en el paquete.

## ¿Qué significa 2 de 3 en v0.5?

Cada autoridad genera su propia clave Ed25519 en su propio dispositivo o servidor. El coordinador registra únicamente los descriptores públicos. Las autoridades reciben propuestas y firman desde su propio entorno. Dos aprobaciones distintas de las tres registradas satisfacen el umbral de autorización.

Las autoridades sincronizan el ledger firmado antes de aprobar una propuesta. La sincronización valida el ancla, todas las firmas y que la nueva secuencia extienda exactamente el historial local. Se rechazan propuestas basadas en un checkpoint anterior.

Esto demuestra **autorización criptográfica con custodia separada**, no un protocolo BFT completo. El coordinador sigue serializando y finalizando el ledger y firma los eventos con la clave del registro. No hay replicación de consenso, líder distribuido, view-change ni resolución de particiones.

## Integración con X.509

El X.509 no se modifica para incrustar HUC-CC. HUC-CC es un certificado complementario separado que referencia el X.509 por SHA-256 de su codificación DER. También referencia el outpoint del evento que emitió esa versión. Esto evita una referencia circular y mantiene el X.509 interoperable.

## Flujo de autoridades independientes

```text
Institución A         Institución B         Institución C
  clave privada         clave privada         clave privada
       |                     |                     |
       +------- descriptores públicos ------------+
                             |
                      Coordinador HUC
                     prepara propuesta
                             |
             propuesta + checkpoint + payloads
                    /        |        \
                 firma A   firma B   firma C
                    \        |        /
                      aprobaciones
                             |
                   quórum 2-de-3 verificado
                             |
                     transición UTXO
                             |
                  paquete de estado firmado
                             |
                 sincronización de A, B y C
```

Las claves privadas de las instituciones nunca se transfieren al coordinador. Los paquetes de enrolamiento y sincronización contienen solo material público.

## Qué se demuestra

1. El X.509 está firmado por la CA local.
2. El CSR demuestra posesión de la clave del titular.
3. HUC-CC está aprobado por un umbral de autoridades.
4. HUC-CC enlaza exactamente al X.509 y su outpoint UTXO.
5. El registro conserva la continuidad de estados.
6. La renovación consume el outpoint previo y crea otro.
7. La revocación consume el outpoint activo sin sucesor.
8. Una segunda operación incompatible no puede consumir el mismo outpoint dentro del workspace local.
