# LAEV HUC 0.5.0 — autoridades independientes

**HUC = Hybrid UTXO Certificate**  
**Componentes:** X.509 + certificado complementario HUC-CC + estado UTXO lógico.  
**Estado:** prototipo funcional de laboratorio con claves de autoridad independientes y aprobaciones fuera de banda; no es una CA pública ni un consenso BFT distribuido.

## Qué incluye

- `certificate.pem`: certificado X.509 emitido por una CA local de demostración.
- `consensus_certificate.json`: HUC-CC independiente, vinculado al hash DER del X.509 y a su outpoint UTXO, con firmas Ed25519 de 2 de 3 autoridades.
- `utxo_ledger.jsonl`: registro de emisión, renovación o revocación. Cada transición tiene firmas del quórum y firma del registro.
- `consensus_policy.json`: define autoridades, permisos y umbral 2-de-3.
- `trust_anchor.json`: fija mediante hashes la CA, la clave pública del registro y la política de consenso.
- `huc.py`: CLI y motor de verificación/estado.
- `huc_federation.py`: generación de claves por autoridad, enrolamiento, propuestas, aprobaciones independientes y finalización.
- `FEDERATED_AUTHORITIES.md`: procedimiento institucional paso a paso.
- `tests/`: pruebas automáticas de ciclo de vida, seguridad de propuestas, sincronización y separación de claves.
- `demo/`: paquetes de ejemplo ACTIVE, SUPERSEDED y REVOKED para inspección.

## Arquitectura funcional

1. **X.509** acredita la asociación entre sujeto y clave pública bajo la CA configurada.
2. **HUC-CC** acredita, mediante un documento complementario firmado, que las autoridades aprobaron la emisión bajo una política concreta y para un outpoint específico.
3. **HUC-UTXO** conserva el estado lógico: ISSUE crea una salida, RENEW consume la anterior y crea una nueva, REVOKE consume la salida activa sin sucesor.
4. **Verificador unificado** comprueba certificado, HUC-CC, política, firmas, ledger, estado y pin de confianza externo.

El HUC-CC no reemplaza X.509 ni modifica el formato estándar. El paquete contiene ambos en paralelo y los enlaza por hash y outpoint.

## Perfil recomendado 0.5: autoridades independientes

**Este es ahora el modo recomendado para probar HUC-CC entre instituciones.** Cada autoridad genera su propia clave Ed25519 en su dispositivo. El coordinador recibe descriptores públicos, nunca claves privadas. Las autoridades descargan una propuesta, revisan su checkpoint, firman los payloads y devuelven aprobaciones. El coordinador finaliza solo si verifica el umbral y la propuesta sigue vigente.

El procedimiento completo está en [FEDERATED_AUTHORITIES.md](FEDERATED_AUTHORITIES.md). Resumen:

1. Cada institución ejecuta `python huc_federation.py authority-init --id ID --out-dir ./authority-ID`.
2. El coordinador inicializa con los descriptores públicos: `python huc.py init --workspace ./huc-workspace --threshold 2 --authority-public ./A/authority-public.json ./B/authority-public.json ./C/authority-public.json`.
3. El coordinador exporta un paquete de enrolamiento diferente para cada institución.
4. Cada autoridad ejecuta `enroll` localmente usando su huella del ancla obtenida por canal independiente.
5. El coordinador prepara la propuesta (`propose-issue`, `propose-renew` o `propose-revoke`).
6. Cada autoridad firma la propuesta en su propio dispositivo mediante `approve`.
7. El coordinador ejecuta `finalize` con al menos dos archivos de aprobación distintos.
8. Tras la transición, se distribuye un paquete de estado y cada autoridad ejecuta `sync` antes de aprobar la siguiente operación.

Los paquetes de enrolamiento, propuestas, aprobaciones y sincronización no contienen claves privadas. `sync` rechaza rollback o bifurcaciones respecto del ledger que ya conoce la autoridad.

### Modo de laboratorio anterior

El comando `huc.py init --authorities 3` sin `--authority-public` sigue generando claves de autoridad locales para pruebas rápidas. **No representa independencia institucional.** Para probar autoridades separadas, usa siempre `--authority-public` y el procedimiento federado 0.5.

Puedes ejecutar una simulación integral de tres dispositivos/directorios:

```bash
bash demo/run_independent_authorities.sh
```

El script crea autoridades temporales, completa una emisión 2-de-3, sincroniza los estados y aprueba una revocación 2-de-3. Al terminar elimina los directorios temporales, incluidas las claves privadas de prueba.

## Instalación

Python 3.10+ recomendado.

```bash
python -m pip install -r requirements.txt
```

En Termux:

```bash
pkg update
pkg install python unzip
python -m pip install -r requirements.txt
```

## Crear un workspace propio

### 1. Inicializar CA, autoridades locales de laboratorio y política

```bash
python huc.py init --workspace ./huc-workspace --threshold 2 --authorities 3
```

El comando devuelve `trust_anchor_sha256`. Guarda esa huella fuera del workspace, por un canal independiente. No confíes en una huella que recibas exclusivamente dentro del mismo ZIP que estás verificando.

### 2. El titular crea su clave y CSR

```bash
python huc.py request --out-dir ./holder-request --name "LAEV Test Holder"
```

La clave privada queda en el equipo del titular. La CA recibe únicamente el archivo CSR.

### 3. Emitir el certificado híbrido (modo local de laboratorio)

```bash
python huc.py issue --workspace ./huc-workspace --csr ./holder-request/LAEV_Test_Holder-FECHA.csr.pem --days 365
```

La operación produce un X.509, un HUC-CC con dos firmas de autoridad y un evento ISSUE que crea la salida UTXO lógica.

En este modo de compatibilidad, las claves de autoridad se guardan en el mismo workspace. Por defecto firman `HUC-AUTH-01` y `HUC-AUTH-02`. Para probar firmantes específicos:

```bash
python huc.py issue --workspace ./huc-workspace --csr ./solicitud.csr.pem --days 365 --signers HUC-AUTH-01,HUC-AUTH-03
```

La operación falla si no se alcanza el umbral. Para custodias independientes entre instituciones, usa el perfil 0.5 descrito arriba en `FEDERATED_AUTHORITIES.md`, no este atajo local.

### 4. Verificar los tres componentes

```bash
python huc.py verify --workspace ./huc-workspace --certificate ./huc-workspace/certificates/certificate-HASH.pem --trust-anchor-sha256 TU_HUELLA_DE_ANCLA
```

La salida muestra `x509_signature_valid`, `huc_cc_valid`, `consensus_reached`, `utxo_status` y `hybrid_valid`.

### 5. Renovar

Genera un CSR nuevo usando el mismo nombre del sujeto:

```bash
python huc.py request --out-dir ./holder-request-renewal --name "LAEV Test Holder"
```

Luego:

```bash
python huc.py renew --workspace ./huc-workspace --certificate RUTA_CERTIFICADO_ANTERIOR.pem --csr RUTA_CSR_NUEVO.csr.pem --days 365
```

La transición consume el UTXO anterior, deja el certificado anterior como `SUPERSEDED` y crea una nueva salida y otro HUC-CC.

### 6. Revocar

```bash
python huc.py revoke --workspace ./huc-workspace --certificate RUTA_CERTIFICADO.pem --reason "key-compromise"
```

La revocación requiere el umbral de firmas, consume el UTXO activo y queda en el ledger. No se permite reactivar el mismo certificado.

### 7. Auditar

```bash
python huc.py audit --workspace ./huc-workspace --trust-anchor-sha256 TU_HUELLA_DE_ANCLA
```

### 8. Exportar un paquete público de revisión

```bash
python huc.py bundle --workspace ./huc-workspace --certificate RUTA_CERTIFICADO.pem --output ./huc-certificate-package.zip
```

Un tercero lo verifica sin tener claves privadas:

```bash
python huc.py verify-bundle --bundle ./huc-certificate-package.zip --trust-anchor-sha256 TU_HUELLA_DE_ANCLA
```

## Los tres paquetes demo

La carpeta `demo/` contiene ZIPs de ejemplo:

- `huc-demo-active.zip`: X.509 + HUC-CC válido + UTXO activo.
- `huc-demo-superseded.zip`: certificado anterior consumido por renovación.
- `huc-demo-revoked.zip`: certificado revocado mediante una transición aprobada.

Cada ZIP incluye su propio ledger y su ancla pública. Los ZIPs no contienen claves privadas. La huella de confianza de cada escenario está en su archivo `.sha256` adyacente. El estado esperado se describe en `demo/README.md`.

## Ejecutar pruebas

```bash
python -m unittest discover -s tests -v
```

## Límites conocidos

- El perfil federado separa las claves privadas de las autoridades y exige sincronizar un checkpoint antes de firmar. Aun así, el coordinador mantiene la secuencia final del ledger y firma sus eventos; esto no es consenso BFT ni tolerancia distribuida completa.
- La CA y la clave privada del ledger siguen custodiadas por el workspace coordinador en este MVP; deben separarse o protegerse mediante HSM/KMS antes de producción.

- El UTXO es un modelo de estado y un registro local JSONL; no hay blockchain, red P2P ni consenso distribuido entre equipos.
- El bloqueo local evita doble consumo concurrente entre procesos que comparten el mismo archivo, pero no resuelve conflictos entre instalaciones independientes.
- El quórum 2-de-3 de este MVP demuestra autorización por múltiples firmas. No equivale a consenso BFT completo: no hay replicación, elección de líder, view-change ni resolución distribuida de particiones.
- Las claves privadas de CA, ledger y autoridades se guardan sin cifrar para facilitar las pruebas. No usar en producción.
- La firma de un CSR demuestra control de una clave, no identidad civil del titular.
- El verificador offline no puede conocer una revocación posterior a su última copia de ledger/estado.
- No se publica OCSP ni CRL, de modo que validadores X.509 tradicionales no consultan automáticamente el estado HUC.
- La serialización JSON de esta versión es un perfil restringido de canonicalización HUC; para interoperabilidad multi-lenguaje de producción se debe implementar y probar completamente RFC 8785 (JCS).

## Seguridad

No incluir claves privadas en GitHub, correos, paquetes de verificación ni documentación. Antes de producción hacen falta HSM/KMS, custodia de autoridad independiente, API segura, auditoría criptográfica externa, política de identidad y privacidad, timestamp confiable, anclaje externo y protocolo de consenso distribuido si se requiere coordinación entre nodos independientes.
