# Paquetes de demostración LAEV HUC 0.4.0

Los siguientes ZIP son paquetes públicos autocontenidos; no incluyen claves privadas.

| Paquete | Resultado esperado | Qué demuestra |
|---|---|---|
| `huc-demo-active.zip` | `VALID / ACTIVE` | X.509 + HUC-CC 2-de-3 + UTXO activo |
| `huc-demo-renewed-active.zip` | `VALID / ACTIVE` | El certificado renovado tiene una salida nueva activa |
| `huc-demo-superseded.zip` | `INVALID / SUPERSEDED` | El certificado anterior fue consumido por renovación |
| `huc-demo-revoked.zip` | `INVALID / REVOKED` | La salida activa fue consumida por una revocación aprobada |

Cada escenario tiene un archivo `.sha256` con la huella del ancla. Verificación reproducible desde la raíz del proyecto:

```bash
bash demo/verify_demos.sh
```

Verificación individual:

```bash
python huc.py verify-bundle --bundle demo/huc-demo-active.zip --trust-anchor-sha256 "$(cat demo/huc-demo-active.sha256)"
```

Los paquetes SUPERSEDED y REVOKED devuelven `hybrid_valid: false` y código de salida 1 de forma intencional. Es el resultado correcto: el archivo sigue siendo criptográficamente auténtico, pero ya no es válido para uso actual.

## Archivos individuales de inspección

`active-artifacts/` contiene los componentes públicos extraídos del paquete ACTIVE:

- `certificate.pem`: X.509.
- `consensus_certificate.json`: HUC-CC complementario con firmas.
- `utxo_ledger.jsonl`: evento UTXO de emisión firmado.
- `consensus_policy.json`: autoridades y política 2-de-3.
- `ca_certificate.pem`: CA pública de demostración.
- `ledger_public.pem`: clave pública verificadora del ledger.
- `trust_anchor.json`: relación de confianza.
- `package_manifest.json`: índice del paquete.

El ejemplo usa una identidad ilustrativa, no una identidad comprobada. La CA no está instalada en los almacenes públicos de confianza.
