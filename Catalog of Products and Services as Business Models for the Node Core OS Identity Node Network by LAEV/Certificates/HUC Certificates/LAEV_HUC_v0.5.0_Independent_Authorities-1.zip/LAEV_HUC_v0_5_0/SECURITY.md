# Modelo de seguridad y límites — LAEV HUC 0.5

## Controles implementados

- Certificado X.509 firmado con RSA-3072 por una CA de laboratorio.
- CSR firmado por el titular; la CA recibe la solicitud pública, no la clave privada del titular.
- HUC-CC separado, vinculado al hash DER X.509 y al outpoint UTXO, firmado por el quórum.
- Claves de autoridad Ed25519 generadas de manera independiente por dispositivo en el perfil federado 0.5.
- Workspace del coordinador configurado con descriptores públicos; no requiere claves privadas de autoridades.
- Propuestas con vencimiento, hash de propuesta, payload UTXO y payload HUC-CC.
- Autoridades que verifican el ancla, la política, los permisos y el checkpoint local antes de firmar.
- Finalizador que comprueba las firmas distintas, el quórum y que la propuesta sigue correspondiendo al estado actual.
- Sincronización pública append-only que rechaza rollback o bifurcación respecto del historial local.
- Bloqueo local anti-equivocación para impedir que una autoridad firme dos propuestas distintas en un mismo checkpoint mientras estén vigentes.
- Firma del evento por una clave Ed25519 distinta del registro.
- Paquetes públicos de enrolamiento, estado y verificación sin claves privadas.
- Pruebas automatizadas de emisión, renovación, revocación, rechazo de propuesta obsoleta, quórum insuficiente y separación de claves.

## Límites importantes

1. **No es blockchain.** El ledger sigue siendo un archivo local firmado; no existe replicación P2P ni consenso entre máquinas para decidir la secuencia global.
2. **No es consenso BFT.** El perfil 2-de-3 es autorización criptográfica distribuida entre custodios independientes, pero el coordinador sigue serializando y finalizando el ledger. No hay elección de líder distribuida, view-change ni resolución BFT de particiones.
3. **Bloqueo anti-equivocación local.** Reduce el doble voto accidental por checkpoint, pero reside en el dispositivo de la autoridad y no equivale a un registro de votos replicado ni a un consenso BFT.
4. **Claves separadas no equivalen a organizaciones validadas.** La demostración genera tres claves en tres directorios separados. En uso institucional, cada entidad debe generar la clave en su propio dispositivo/servidor, aplicar sus controles internos y confirmar la huella del ancla por un canal independiente.
5. **Custodia local del coordinador.** La CA y la clave privada que firma el ledger permanecen en el workspace coordinador en este MVP. Se deben separar/proteger mediante HSM/KMS o custodios dedicados antes de producción.
6. **Claves privadas de demostración sin cifrar.** Las claves de CA, ledger y autoridades se almacenan en PEM sin contraseña para simplificar laboratorio. No utilizar esta custodia en producción.
7. **Identidad no validada.** La firma del CSR demuestra control de una clave, no que el sujeto sea realmente quien dice ser.
8. **Frescura offline.** Un paquete desconectado solo demuestra el estado reflejado por el ledger incluido. No puede detectar una revocación posterior que no haya recibido.
9. **Sin OCSP/CRL.** Los navegadores y validadores X.509 tradicionales no consultan automáticamente el estado HUC.
10. **Timestamps locales.** Las marcas de tiempo proceden del reloj del sistema; no son sellos de tiempo de un tercero confiable.
11. **JSON canónico restringido.** El perfil del MVP limita floats y claves a ASCII. La interoperabilidad multi-lenguaje de producción requiere implementar completamente RFC 8785 JCS y sus vectores de prueba.
12. **Sin uso crítico.** No usar para TLS público, identidad legal, licencias profesionales, pagos, acceso crítico ni cumplimiento normativo.

## Requisitos antes de producción

- HSM/KMS o almacenes de claves protegidos en cada institución.
- Proceso documentado de enrolamiento, acreditación, revocación y rotación de autoridades.
- Custodia independiente de CA y clave del registro.
- Protocolo de consenso replicado formal si se requiere tolerancia a fallos bizantinos y coordinador no confiable.
- Checkpoints externos firmados y protección anti-rollback.
- Timestamp confiable y política formal de frescura.
- OCSP/CRL bridge si se necesita compatibilidad con consumidores X.509 clásicos.
- Canonicalización RFC 8785 y vectores de interoperabilidad.
- Revisión criptográfica independiente, pruebas de penetración, auditoría externa y revisión legal.
